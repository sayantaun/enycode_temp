
export interface FormOptionModel {
    text: string;
    value: string;
}
