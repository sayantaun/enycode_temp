
export * from './menu-config';
