import {atom} from "jotai";

export const activeItemAtom = atom('')
