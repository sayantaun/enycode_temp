export * from './NegativeNewsView.tsx'
