import requests
import os
from dotenv import load_dotenv

def get_iam_token():

    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json',
    }

    data = {
        'grant_type': 'urn:ibm:params:oauth:grant-type:apikey',
        'apikey': os.environ.get("cloud_api_key"),
    }

    response = requests.post('https://iam.cloud.ibm.com/identity/token', headers=headers, data=data, verify=False)
    return response.json()['access_token']

def execute_prompt(deployment_id, prompt_variables):
    headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'Authorization': 'Bearer ' + get_iam_token(),
    }

    params = {
        'version': '2021-05-01',
    }

    json_data = {
        'parameters': {
            'prompt_variables': prompt_variables
        },
    }
    response = requests.post(
        f'{os.environ.get("wml_endpoint")}/ml/v1/deployments/{deployment_id}/text/generation',
        params=params,
        headers=headers,
        json=json_data,
    )

    return response.json()["results"][0]["generated_text"]


load_dotenv()
news = "FTX Trading Ltd. - BREAKING: Sam Bankman-Fried, the disgraced founder and former CEO of the collapsed cryptocurrency empire FTX, has been found GUILTY on a slew of heinous charges including fraud and money laundering, after a dramatic month-long trial that laid bare his staggering deceit. He faces severe punishment with the potential for up to 20 years behind bars for each of the more egregious offenses—two counts of wire fraud conspiracy, two counts of wire fraud, one count of conspiracy to commit money laundering, one count of conspiracy to commit commodities fraud, and one count of conspiracy to commit securities fraud. The verdict, which could seal his fate for decades, comes on the heels of FTX's shocking bankruptcy nearly a year ago, sparked by a damning report that unveiled the company’s shaky foundations, igniting an immediate and catastrophic downfall. Bankman-Fried, who shamelessly pilfered customer funds to bankroll his personal and political extravaganzas, is set to be sentenced in March. As if that wasn't enough, he's also bracing for another trial on further charges including foreign bribery. Since August, Bankman-Fried has been locked up, with his bail revoked following accusations of witness tampering—a clear sign of his desperate attempts to manipulate justice. As the cryptocurrency world reels from this epic downfall, the question looms: How did he think he could get away with it? Stay tuned as we continue to cover this blockbuster story of greed, betrayal, and corruption."


print(execute_prompt("53dd60e5-49e5-43d6-a782-935270b1a51e", {"text" : news}))