# negative-news-ga

## python3 -m venv env
## source env/bin/activate
## pip3 install -r requirements.txt

### add apikeys to .env

## streamlit run app.py
