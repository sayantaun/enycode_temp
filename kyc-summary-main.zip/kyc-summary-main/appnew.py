import requests
import urllib.request
from bs4 import BeautifulSoup
from dotenv import load_dotenv
import os
import json
import re
from array import array

from ibm_watson import DiscoveryV2
from ibm_watson.discovery_v2 import QueryLargePassages
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator

from ibm_cloud_sdk_core import IAMTokenManager
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator, BearerTokenAuthenticator
from flask import Flask

import logging

app = Flask(__name__)

def generate(input, model_id, parameters):
    api_key = os.environ["IBM_CLOUD_API_KEY"]
    project_id = os.environ["PROJECT_ID"]

    access_token = IAMTokenManager(
        apikey = api_key,
        url = "https://iam.cloud.ibm.com/identity/token"
    ).get_token()

    wml_url = "https://us-south.ml.cloud.ibm.com/ml/v1-beta/generation/text?version=2023-05-28"
    Headers = {
        "Authorization": "Bearer " + access_token,
        "Content-Type": "application/json",
        "Accept": "application/json"
    }
    data = {
        "model_id": model_id,
        "input": input,
        "parameters": parameters,
        "project_id": project_id
    }
    response = requests.post(wml_url, json=data, headers=Headers)
    if response.status_code == 200:
        return response.json()["results"][0]["generated_text"]
    else:
        return ""


def get_text_from_wd_for_people(entity, query, project_id, collection_id):
    print("get_text_from_wd_for_people")
    authenticator = IAMAuthenticator(os.environ["WD_API_KEY"])
    wd_client = DiscoveryV2(
        version="2020-08-30",
        authenticator=authenticator
    )
    wd_client.set_service_url(os.environ["WD_SERVICE_URL"])

    result_text = ""
    try:
        response = wd_client.query(
            project_id=project_id,
            collection_ids=[collection_id],
            natural_language_query=query,
            count = 50
        ).get_result()
        
        results = []
        for i in range(len(response["results"])):
            entity_found = False
            #Check if entity
            if "title" in response["results"][i]["extracted_metadata"]:
                title = response["results"][i]["extracted_metadata"]["title"]
                tocheck = (entity + " people").lower()
                print("title " + title)
                print("tocheck " + tocheck)
                if tocheck in title.lower():
                    print("title " + title)
                    print("tocheck " + tocheck)
                    entities = response["results"][i]["enriched_text"][0]["entities"]
                    for k in range(len(entities)):
                        if entities[k]["type"] == "Organization":
                            if entities[k]["text"].lower().find(entity.lower()) != -1:
                                entity_found = True
                                break
                    if entity_found:
                        result_text = response["results"][i]["text"][0]
                        break
            elif "people".lower() in response["results"][i]["extracted_metadata"]["filename"].lower():
                tocheck = (entity + " people").lower()
                entities = response["results"][i]["enriched_text"][0]["entities"]
                for k in range(len(entities)):
                    if entities[k]["type"] == "Organization":
                        if entities[k]["text"].lower().find(entity.lower()) != -1:
                            entity_found = True
                            break
                if entity_found:
                    result_text = response["results"][i]["text"][0]
                    break
    except Exception as error:
        logging.error("Failed to fetch documented from Watson Discovery", str(error))
    
    if type(result_text) == list:
        return result_text[0]
    else:
        return result_text
    

def get_text_from_web_for_people(entity, query, project_id, collection_id):
    print("get_text_from_web_for_people")
    authenticator = IAMAuthenticator(os.environ["WD_API_KEY"])
    wd_client = DiscoveryV2(
        version="2020-08-30",
        authenticator=authenticator
    )
    wd_client.set_service_url(os.environ["WD_SERVICE_URL"])

    result_text = ""
    try:
        response = wd_client.query(
            project_id=project_id,
            collection_ids=[collection_id],
            natural_language_query=query
        ).get_result()
        
        results = []
        for i in range(len(response["results"])):
            entity_found = False
            #Check if entity
            entities = response["results"][i]["enriched_text"][0]["entities"]
            for k in range(len(entities)):
                if entities[k]["type"] == "Organization":
                    if entities[k]["text"].lower().find(entity.lower()) != -1:
                        entity_found = True
                        break
            if entity_found:
                officers = response["results"][i]["extracted_metadata"]["filename"]
                url = response["results"][i]["metadata"]["source"]["url"]
                expected_url = "https://find-and-update.company-information.service.gov.uk/company/"
                if (expected_url in url) & (officers in url) :
                    result_text = response["results"][i]["text"][0]
                    break
        
    except Exception as error:
        logging.error("Failed to fetch documented from Watson Discovery", str(error))
    
    if type(result_text) == list:
        return result_text[0]
    else:
        return result_text


def get_text_from_wd_with_filter(entity, query, project_id, collection_id):
    print("get_text_from_wd_with_filter")
    authenticator = IAMAuthenticator(os.environ["WD_API_KEY"])
    wd_client = DiscoveryV2(
        version="2020-08-30",
        authenticator=authenticator
    )
    wd_client.set_service_url(os.environ["WD_SERVICE_URL"])

    result_text = ""
    try:
        response = wd_client.query(
            project_id=project_id,
            collection_ids=[collection_id],
            natural_language_query=query
        ).get_result()
        
        results = []
        for i in range(len(response["results"])):
            entity_found = False
            #Check if entity
            entities = response["results"][i]["enriched_text"][0]["entities"]
            for k in range(len(entities)):
                if entities[k]["type"] == "Organization":
                    if entities[k]["text"].lower().find(entity.lower()) != -1:
                        entity_found = True
                        break
            if entity_found:
                number = response["results"][i]["extracted_metadata"]["filename"]
                url = response["results"][i]["metadata"]["source"]["url"]
                expected_url = "https://find-and-update.company-information.service.gov.uk/company/" + number
                if url == expected_url:
                    result_text = response["results"][i]["text"][0]
                    break
    
    except Exception as error:
        logging.error("Failed to fetch documented from Watson Discovery", str(error))
    
    if type(result_text) == list:
        return result_text[0]
    else:
        return result_text
    

def get_documents_from_wd(entity, query, project_id, collection_id):
    
    authenticator = IAMAuthenticator(os.environ["WD_API_KEY"])
    wd_client = DiscoveryV2(
        version="2020-08-30",
        authenticator=authenticator
    )
    wd_client.set_service_url(os.environ["WD_SERVICE_URL"])

    all_results = ""

    passages = {"enabled": True, "per_document": True, "find_answers": True, "max_per_document": 4, "characters": 600}
    query_large_passages_model = QueryLargePassages.from_dict(passages)

    try:
        response = wd_client.query(
            project_id=project_id,
            collection_ids=[collection_id],
            natural_language_query=query,
            passages=query_large_passages_model#,
            #return_=["text"]
        ).get_result()
        
        results = []
            
        for i in range(len(response["results"])):
            entity_found = False
            #Check if entity
            entities = response["results"][i]["enriched_text"][0]["entities"]
            for k in range(len(entities)):
                if entities[k]["type"] == "Organization":
                    if entities[k]["text"].lower().find(entity.lower()) != -1:
                        entity_found = True
                        break
            if entity_found:
                passages = response["results"][i]["document_passages"]
                results = []
                for item in passages:
                    item = item["passage_text"].replace("<em>","")
                    item = item.replace("</em>", "")
                    results.append(item)
                
                nresults = "".join(results)
                if nresults.lower().find(all_results.lower()) != -1:
                    all_results = all_results + "\n".join(results)

    except Exception as error:
        print("Failed to fetch documented from Watson Discovery", str(error))
    
    return all_results

def get_documents_from_wd_for_annual(entity, query, project_id, collection_id):
    
    authenticator = IAMAuthenticator(os.environ["WD_API_KEY"])
    wd_client = DiscoveryV2(
        version="2020-08-30",
        authenticator=authenticator
    )
    wd_client.set_service_url(os.environ["WD_SERVICE_URL"])

    all_results = ""

    passages = {"enabled": True, "per_document": True, "find_answers": True, "max_per_document": 4, "characters": 1000}
    query_large_passages_model = QueryLargePassages.from_dict(passages)

    try:
        response = wd_client.query(
            project_id=project_id,
            collection_ids=[collection_id],
            natural_language_query=query,
            passages=query_large_passages_model#,
            #return_=["text"]
        ).get_result()
        
        results = []
            
        for i in range(len(response["results"])):
            entity_found = False
            #Check if entity
            entities = response["results"][i]["enriched_text"][0]["entities"]
            for k in range(len(entities)):
                if entities[k]["type"] == "Organization":
                    if entities[k]["text"].lower().find(entity.lower()) != -1:
                        entity_found = True
                        break
            if entity_found:
                passages = response["results"][i]["document_passages"]
                results = []
                for item in passages:
                    item = item["passage_text"].replace("<em>","")
                    item = item.replace("</em>", "")
                    results.append(item)
                
                nresults = "".join(results)
                if nresults.lower().find(all_results.lower()) != -1:
                    all_results = all_results + "\n".join(results)

    except Exception as error:
        print("Failed to fetch documented from Watson Discovery", str(error))
    
    return all_results


def get_documents_from_wd_with_filter(entity, query, project_id, collection_id):
    
    authenticator = IAMAuthenticator(os.environ["WD_API_KEY"])
    wd_client = DiscoveryV2(
        version="2020-08-30",
        authenticator=authenticator
    )
    wd_client.set_service_url(os.environ["WD_SERVICE_URL"])

    all_results = ""

    passages = {"enabled": True, "per_document": True, "find_answers": True, "max_per_document": 2, "characters": 600}
    query_large_passages_model = QueryLargePassages.from_dict(passages)

    try:
        response = wd_client.query(
            project_id=project_id,
            collection_ids=[collection_id],
            natural_language_query=query,
            passages=query_large_passages_model#,
            #return_=["text"]
        ).get_result()
        
        results = []
            
        for i in range(len(response["results"])):
            entity_found = False
            source_found = False
            #Check if entity
            entities = response["results"][i]["enriched_text"][0]["entities"]
            for k in range(len(entities)):
                if entities[k]["type"] == "Organization":
                    if entities[k]["text"].lower().find(entity.lower()) != -1:
                        entity_found = True
                        if entity_found & source_found:
                            break
                    if entities[k]["text"].lower().find("GOV.UK Find and update company information Companies House".lower()) != -1 or "Companies House".lower().find(entities[k]["text"].lower()) != -1:
                        source_found = True
                        if entity_found & source_found:
                            break
            if entity_found & source_found:
                passages = response["results"][i]["document_passages"]
                results = []
                for item in passages:
                    item = item["passage_text"].replace("<em>","")
                    item = item.replace("</em>", "")
                    results.append(item)
                
                nresults = "".join(results)
                if nresults.lower().find(all_results.lower()) != -1:
                    all_results = all_results + "\n".join(results)
                break

    except Exception as error:
        print("Failed to fetch documented from Watson Discovery", str(error))
    
    return all_results


def generate_summary_annual_performance_new(entity, project_id, collection_id):
    print("in generate_summary_annual_performance_new")
    turnover = ""
    profit = ""
    employees = ""
    params = {
        "decoding_method": "greedy",
        "max_new_tokens": 200,
        "min_new_tokens": 1,
        "repetition_penalty": 1
    }

    input = "what was the turnover on book or revenue for the financial year for " + entity + "?"
    result_text = get_documents_from_wd_for_annual(entity, input, project_id, collection_id)
    if result_text is not None and result_text != "":
        prompt = 'Use the following pieces of context to answer the question at the end. If you don\'t know the answer, say I don\'t know, do not try to make up an answer.' + '\n\n' + result_text + '\n\n' + 'Question: ' + input + '\n\n' + 'Helpful Answer:\n'
        print("\nRevenue prompt - " + prompt)
        turnover = generate(prompt, "meta-llama/llama-2-70b-chat", params)
        if "I don't know" in turnover:
            turnover = ""
        
    print("Turnover " + turnover)

    input = "what was the profit for the financial year for " + entity + "?"
    result_text = get_documents_from_wd_for_annual(entity, input, project_id, collection_id)

    if result_text is not None and result_text != "":
        prompt = 'Use the following pieces of context to answer the question at the end. If you don\'t know the answer, say I don\'t know, do not try to make up an answer.' + '\n\n' + result_text + '\n\n' + 'Question: ' + input + '\n\n' + 'Helpful Answer:\n'
        print("\nProfit prompt - " + prompt)
        profit = generate(prompt, "meta-llama/llama-2-70b-chat", params)
        if "I don't know" in profit:
            profit = ""

    print("Profit " + profit)

    input = "how many employees were there for the financial year in " + entity + "?"
    result_text = get_documents_from_wd_for_annual(entity, input, project_id, collection_id)

    if result_text is not None and result_text != "":
        prompt = 'Use the following pieces of context to answer the question at the end. If you don\'t know the answer, say I don\'t know, do not try to make up an answer.' + '\n\n' + result_text + '\n\n' + 'Question: ' + input + '\n\n' + 'Helpful Answer:\n'
        print("\nEmployees prompt - " + prompt)
        employees = generate(prompt, "meta-llama/llama-2-70b-chat", params)
        if "I don't know" in employees:
            employees = ""

    print("Employees " + employees)

    summary = turnover + profit + employees
    summary = summary.replace("Output:", "")
    return summary


def generate_summary_company_people_from_doc(entity, project_id, collection_id):
    print(generate_summary_company_people_from_doc)
    params = {
        "decoding_method": "greedy",
        "max_new_tokens": 400,
        "min_new_tokens": 1,
        "repetition_penalty": 1
    }

    input = 'who all are playing role of Active Directors or Secretary and not resigned in ' + entity
    #about_people = get_text_from_wd(entity, input, project_id, collection_id)
    about_people = get_text_from_wd_for_people(entity, input, project_id, collection_id)
    #print(about_people)
    about_people = re.sub(r'\n+', '\n', about_people)
    about_people = re.sub(r'\s+', ' ', about_people)
    summary = ""
    
    if about_people is not None and about_people != "":
        input = 'who all are playing role of Active Directors or Secretary and not resigned in ' + entity + '?\n'
        prompt = """Use the following pieces of context to answer the question at the end. If you don't know the answer, do not try to make up an answer.\n
    """ + about_people + """\nQuestion: """ + input + """\nHelpful Answer: """
        print(prompt)
        summary = generate(prompt, "meta-llama/llama-2-70b-chat", params)
        print("people summary : " + summary)
        summary = summary.replace("Output:", "")
    return summary


def generate_summary_company_people_from_web(entity, project_id, collection_id):
    print("generate_summary_company_people_from_web")
    params = {
        "decoding_method": "greedy",
        "max_new_tokens": 400,
        "min_new_tokens": 1,
        "repetition_penalty": 1
    }

    input = 'who all are playing role of Active Directors or Secretary and not resigned in ' + entity
    #about_people = get_text_from_wd(entity, input, project_id, collection_id)
    about_people = get_text_from_web_for_people(entity, input, project_id, collection_id)
    #print(about_people)
    about_people = re.sub(r'\n+', '\n', about_people)
    about_people = re.sub(r'\s+', ' ', about_people)
    summary = ""
    
    if about_people is not None and about_people != "":
        input = 'who all are playing role of Active Directors or Secretary and not resigned in ' + entity + '?\n'
        prompt = """Use the following pieces of context to answer the question at the end. If you don't know the answer, don't try to make up an answer.\n\n
    """ + about_people + """\n\nQuestion: """ + input + """\n\nHelpful Answer: """
        print(prompt)
        summary = generate(prompt, "meta-llama/llama-2-70b-chat", params)
        #print("people summary : " + summary)
        summary = summary.replace("Output:", "")
    return summary


def generate_summary_company_shares(entity, project_id, collection_id):
    params = {
        "decoding_method": "greedy",
        "max_new_tokens": 400,
        "min_new_tokens": 10,
        "repetition_penalty": 1
    }
    #shareholdings = get_documents_from_wd('Full details of initial shareholdings or shareholders in ' + entity + 'from confirmation statement', project_id, collection_id)
    shareholdings = get_documents_from_wd(entity, 'For ' + entity + ', give full details of initial shareholdings or shareholders with number of shares', project_id, collection_id)
    #print(shareholdings)
    summary = ""
    if shareholdings is not None and shareholdings != "":
        input = 'generate a summary of all the shareholders information with their names and number of shares held by them'
        prompt = 'Use the following pieces of context to answer the question at the end. If you don\'t know the answer, don\'t try to make up an answer.' + '\n' + shareholdings + '\n' + 'Question: ' + input + '\n' + 'Helpful Answer:'
        print(prompt)
        summary = generate(prompt, "meta-llama/llama-2-70b-chat", params)
        summary = summary.replace("Output:", "")
        if "Unfortunately, the information you're looking for is not available" in summary or "information you are seeking is not available " in summary or "The information you're asking for is not available in the provided context" in summary or "information you've provided doesn't contain the names" in summary or "not able to generate a summary of shareholder information" in summary or "not able to provide a summary of" in summary or "information you have requested is not available" in summary or "information you requested is not available" in summary:
            summary = ""
        print('Shares summary : ' + summary)
    if "I cannot generate a summary" in summary:
        return ""
    else:
        return summary
    
    
def generate_company_overview_summary_from_web(entity, project_id, collection_id):
    params = {
        "decoding_method": "greedy",
        "max_new_tokens": 400,
        "min_new_tokens": 1,
        "repetition_penalty": 1
    }

    summary = ""
    overview = get_text_from_wd_with_filter(entity, 'what is the registered address, incorporation date and nature of business for ' + entity, project_id, collection_id)
    overview = overview.replace("\n", "")
    overview = re.sub(r'\s+', ' ', overview)
    #print("Overview : " + overview)
    if overview is not None and overview != "":
        prompt = '''Use the below text to generate an overview summary for company ''' + entity + '''. Include Company registration date, address, nature of business in the summary if available.\n\n''' + '''Input: \nSkip to main content                  GOV.UK                              Find and update company information            Companies House does not verify the accuracy of the information filed(link opens a new window)Sign in / RegisterSign in / RegisterSearch for a company or officerSearchPlease press ENTER to searchAdvanced company searchLink opens in new windowBROOKHOUSE AEROSPACE LIMITED            Company number            01898700Follow this company                      File for this company                            Company Overview for BROOKHOUSE AEROSPACE LIMITED (01898700)Filing history for BROOKHOUSE AEROSPACE LIMITED (01898700)People for BROOKHOUSE AEROSPACE LIMITED (01898700)Charges for BROOKHOUSE AEROSPACE LIMITED (01898700)More for BROOKHOUSE AEROSPACE LIMITED (01898700)Registered office addressIndia Mill, Darwen, Lancashire, BB3 1AD            Company status                    Active                Company type                Private limitedHide this message      Cookies on Companies House servicesWe use cookies to make our services work and collect analytics information. To accept or reject analytics cookies, turn on JavaScript in your browser settings and reload this page.Skip to main content                  GOV.UK                              Find and update company information            Companies House does not verify the accuracy of the information filed(link opens a new window)Sign in / RegisterSign in / RegisterSearch for a company or officerSearchPlease press ENTER to searchAdvanced company searchLink opens in new windowBROOKHOUSE AEROSPACE LIMITED

Output:\nBrookhouse Aerospace Limited is a privately held company that was established on March 25, 1985, in the United Kingdom. It's registered office address is India Mill, Darwen, Lancashire, BB3 1AD. This company falls under the category of manufacturing various plastic products and is headquartered in Lancashire, UK. 

Input:\nSkip to main content                  GOV.UK                              Find and update company information            Companies House does not verify the accuracy of the information filed(link opens a new window)Sign in / RegisterSign in / RegisterSearch for a company or officerSearchPlease press ENTER to searchAdvanced company searchLink opens in new windowANTOFAGASTA PLC            Company number            01627889Follow this company                      File for this company                            Company Overview for ANTOFAGASTA PLC (01627889)Filing history for ANTOFAGASTA PLC (01627889)People for ANTOFAGASTA PLC (01627889)Charges for ANTOFAGASTA PLC (01627889)More for ANTOFAGASTA PLC (01627889)Registered office address103 Mount Street, London, United Kingdom, W1K 2TJ            Company statusHide this message      Cookies on Companies House servicesWe use cookies to make our services work and collect analytics information. To accept or reject analytics cookies, turn on JavaScript in your browser settings and reload this page.Skip to main content                  GOV.UK                              Find and update company information            Companies House does not verify the accuracy of the information filed(link opens a new window)Sign in / RegisterSign in / RegisterSearch for a company or officerSearchPlease press ENTER to searchAdvanced company searchLink opens in new windowANTOFAGASTA PLC            Company

Output:\nAntofagasta PLC is a Public listed company which was incorporated in the United Kingdom on 7 April 1982. It's registered address is 103 Mount Street, London, United Kingdom, W1K 2TJ. Company's nature of business is Mining of other non-ferrous metal ores, Freight rail transport and Freight transport by road. \n\nInput:\n''' + overview + '''\n\nOutput:\n'''
        
        #print(prompt)
        summary = generate(prompt, "meta-llama/llama-2-70b-chat", params)

    return summary


def generate_company_overview_summary_from_doc(entity, project_id, collection_id):
    print("generate_company_overview_summary_from_doc")
    params = {
        "decoding_method": "greedy",
        "max_new_tokens": 400,
        "min_new_tokens": 1,
        "repetition_penalty": 1
    }

    summary = ""
    overview = get_documents_from_wd_with_filter(entity, 'what is the registered address, incorporation date and nature of business for ' + entity, project_id, collection_id)
    overview = overview.replace("\n", "")
    overview = re.sub(r'\s+', ' ', overview)
    if overview is not None and overview != "":
        prompt = '''Use the below text to generate an overview summary for company ''' + entity + '''. Include Company registration date, address, nature of business in the summary if available.\n\n''' + '''Input: Skip to main content                  GOV.UK                              Find and update company information            Companies House does not verify the accuracy of the information filed(link opens a new window)Sign in / RegisterSign in / RegisterSearch for a company or officerSearchPlease press ENTER to searchAdvanced company searchLink opens in new windowBROOKHOUSE AEROSPACE LIMITED            Company number            01898700Follow this company                      File for this company                            Company Overview for BROOKHOUSE AEROSPACE LIMITED (01898700)Filing history for BROOKHOUSE AEROSPACE LIMITED (01898700)People for BROOKHOUSE AEROSPACE LIMITED (01898700)Charges for BROOKHOUSE AEROSPACE LIMITED (01898700)More for BROOKHOUSE AEROSPACE LIMITED (01898700)Registered office addressIndia Mill, Darwen, Lancashire, BB3 1AD            Company status                    Active                Company type                Private limitedHide this message      Cookies on Companies House servicesWe use cookies to make our services work and collect analytics information. To accept or reject analytics cookies, turn on JavaScript in your browser settings and reload this page.Skip to main content                  GOV.UK                              Find and update company information            Companies House does not verify the accuracy of the information filed(link opens a new window)Sign in / RegisterSign in / RegisterSearch for a company or officerSearchPlease press ENTER to searchAdvanced company searchLink opens in new windowBROOKHOUSE AEROSPACE LIMITED

Output: Brookhouse Aerospace Limited is a privately held company that was established on March 25, 1985, in the United Kingdom. It's registered office address is India Mill, Darwen, Lancashire, BB3 1AD. This company falls under the category of manufacturing various plastic products and is headquartered in Lancashire, UK. 

Input: Skip to main content                  GOV.UK                              Find and update company information            Companies House does not verify the accuracy of the information filed(link opens a new window)Sign in / RegisterSign in / RegisterSearch for a company or officerSearchPlease press ENTER to searchAdvanced company searchLink opens in new windowANTOFAGASTA PLC            Company number            01627889Follow this company                      File for this company                            Company Overview for ANTOFAGASTA PLC (01627889)Filing history for ANTOFAGASTA PLC (01627889)People for ANTOFAGASTA PLC (01627889)Charges for ANTOFAGASTA PLC (01627889)More for ANTOFAGASTA PLC (01627889)Registered office address103 Mount Street, London, United Kingdom, W1K 2TJ            Company statusHide this message      Cookies on Companies House servicesWe use cookies to make our services work and collect analytics information. To accept or reject analytics cookies, turn on JavaScript in your browser settings and reload this page.Skip to main content                  GOV.UK                              Find and update company information            Companies House does not verify the accuracy of the information filed(link opens a new window)Sign in / RegisterSign in / RegisterSearch for a company or officerSearchPlease press ENTER to searchAdvanced company searchLink opens in new windowANTOFAGASTA PLC            Company

Output: Antofagasta PLC is a Public listed company which was incorporated in the United Kingdom on 7 April 1982. It's registered address is 103 Mount Street, London, United Kingdom, W1K 2TJ. Company's nature of business is Mining of other non-ferrous metal ores, Freight rail transport and Freight transport by road. \n\nInput: ''' + overview + '''\n\nOutput: '''
        
        #print(prompt)
        summary = generate(prompt, "meta-llama/llama-2-70b-chat", params)
    return summary


@app.route('/summarise/<entity>', methods=["GET"])
def generate_summary(entity = None):
    summary = ""
    summary_1 = ""
    summary_2 = ""
    summary_3 = ""
    summary_4 = ""
    summary_5 = ""
    website_wd_project_id = ""
    website_wd_collection_id = ""
    docs_wd_project_id = ""
    docs_wd_collection_id = ""
    company_information_url = ""

    #load entity config information from json
    company_config_json_file = "./company-config-new.json"
    with open(company_config_json_file, 'r') as json_file:
        data = json.load(json_file)
    
    entity_not_found = True
    companies = data['companies']
    for company in companies:
        if entity == company['company']:
            website_wd_project_id = company['website_wd_project_id']
            website_wd_collection_id = company['website_wd_collection_id']
            docs_wd_project_id = company['docs_wd_project_id']
            docs_wd_collection_id = company['docs_wd_collection_id']
            company_information_url = company['company_information_url']
            entity_not_found = False
            break
    
    if entity_not_found:
        website_wd_project_id = company['website_wd_project_id']
        website_wd_collection_id = company['website_wd_collection_id']
        docs_wd_project_id = company['docs_wd_project_id']
        docs_wd_collection_id = company['docs_wd_collection_id']
        

    summary_2 = generate_company_overview_summary_from_web(entity, docs_wd_project_id, website_wd_collection_id)
    if summary_2 is None or summary_2 == "":
        summary_2 = generate_company_overview_summary_from_doc(entity, docs_wd_project_id, docs_wd_collection_id)
    #print("summary_2" + summary_2)

    summary_3 = generate_summary_annual_performance_new(entity, docs_wd_project_id, docs_wd_collection_id)
    #print("summary_3" + summary_3)

    summary_4 = generate_summary_company_people_from_doc(entity, docs_wd_project_id, docs_wd_collection_id)
    if summary_4 is None or summary_4 == "":
        summary_4 = generate_summary_company_people_from_web(entity, docs_wd_project_id, website_wd_collection_id)
    summary_4 = summary_4.replace("(Note: I'll be happy to help you with this question. Please note that I'll only provide the answer based on the given context, and I won't make up an answer if I don't know it.)", "")
    #print("summary_4" + summary_4)

    summary_5 = generate_summary_company_shares(entity, docs_wd_project_id, docs_wd_collection_id)
    #print("summary_5" + summary_5)

    summary = summary_1 + '\n\n' + summary_2 + '\n\n' + summary_3 + '\n\n' + summary_4 + '\n\n' + summary_5
    print(summary)

    return summary

if __name__ == "__main__":
    # Run the Flask app
    app.run(port=8080)