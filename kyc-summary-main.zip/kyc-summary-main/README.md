# kyc-summary

You need a .env file
WD_API_KEY=""
WD_SERVICE_URL=""
PROJECT_ID=""
IBM_CLOUD_API_KEY=""
