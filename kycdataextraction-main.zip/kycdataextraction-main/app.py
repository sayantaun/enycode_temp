import streamlit as st
import datetime
import time
from ibm_watson import DiscoveryV2
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
import json
import requests
import os, types
import pandas as pd
from botocore.client import Config
import ibm_boto3
from ibm_cloud_sdk_core import IAMTokenManager
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator, BearerTokenAuthenticator
import getpass
import numpy as np
from streamlit_option_menu import option_menu

class Prompt:
    def __init__(self, access_token, project_id):
        self.access_token = access_token
        self.project_id = project_id

    def generate(self, input, model_id, parameters):
        wml_url = os.getenv("WML_URL")
        #"https://us-south.ml.cloud.ibm.com/ml/v1-beta/generation/text?version=2023-05-28"
        Headers = {
            "Authorization": "Bearer " + self.access_token,
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
        data = {
            "model_id": model_id,
            "input": input,
            "parameters": parameters,
            "project_id": self.project_id
        }
        response = requests.post(wml_url, json=data, headers=Headers)
        return response

def similar(str1, str2):
    str1 = str1 + ' ' * (len(str2) - len(str1))
    str2 = str2 + ' ' * (len(str1) - len(str2))
    return sum(1 if i == j else 0
               for i, j in zip(str1, str2)) / float(len(str1))

collection_id = os.getenv("WDS_COLLECTION_ID")
project_id = os.getenv("WDS_PROJECT_ID")
watsonxai_project_id=os.getenv("WATSONX_PROJECT_ID")
print(os.getenv("WDS_APIKEY"))
authenticator = IAMAuthenticator(os.getenv("WDS_APIKEY"))
discovery = DiscoveryV2(version='2020-08-30',authenticator=authenticator)
discovery.set_service_url(os.getenv("WDS_URL"))
access_token = IAMTokenManager(apikey = os.getenv("IAM_KEY"),url = "https://iam.cloud.ibm.com/identity/token").get_token()
discoveryQuestion="What is the registered address of BROOKHOUSE AEROSPACE LIMITED?"

with st.sidebar:
    selected = option_menu("KYC-DataExtraction", ["Upload KYC Documents", 'KYC Data Extraction'], 
        icons=['bank', 'gear'], menu_icon="cast", default_index=0)

st.subheader("Demo - KYC Validation ")     
st.markdown("---")
## Option to Upload KYC Document 
## * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
if selected == "Upload KYC Documents":  
    st.image('arc.png', caption='KYC Data Extraction')
    st.subheader("Upload KYC Documents (File size limit: 10 mb)")
    uploaded_file = st.file_uploader("Upload KYC Document",label_visibility="hidden")
    st.write("Note : Upload documents like Company Annual Report or Company related documents and the content will be extracted and stored in a collection. You can ask question in natural language and watsonx.ai will provide answer. ")
    st.write("Once you upload the document, click on Data Extraction to ask questions!")
    if uploaded_file is not None:
        data=uploaded_file.getvalue()
        savepath = uploaded_file.name
        try:
            destination_file = open(savepath,mode='wb')
            destination_file.write(data)
            st.write("File Saved to " , destination_file)
            destination_file.close()
        except EOFError:
            print("error")
            
        with open(os.path.join(uploaded_file.name), "rb") as file:
            #file.write(uploaded_file.getbuffer())   
            with st.spinner('Wait for it...'):
                add_doc_response = discovery.add_document(
                    project_id=project_id,
                    collection_id=collection_id, 
                    file=file, 
                    file_content_type='application/pdf').get_result()
                print (add_doc_response)
                # Getting the ID of the newly added document
                new_document_id = add_doc_response.get("document_id", None)
            st.write("Document ",uploaded_file.name, "successfully uploaded. It will take few minutes to extract the content and normalize into discovery collection. click on KCY Data Extraction after fewminutes to extract KYC data.")     
                
            if new_document_id:
                print(f"Newly added document ID: {new_document_id}")
            else:
                print("Error getting document ID.")    
## Option to Upload KYC Document 
## * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
else:
## Model Comarision based on KYC Data Extraction 
## Input : CSV file with questions
## Option to choose two models to compare Performance | Tokens consumed | Cost 
## * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
    customerName = st.text_input('Enter Customer Name: ')
    st.write("Note : If no customer name specified then pre-populdatd data related to BROOKHOUSE AEROSPACE LIMITED will be considered to answer questions")
    if customerName == "":
       customerName =  "BROOKHOUSE AEROSPACE LIMITED"
    spectra_df = pd.DataFrame()
    spectra_df2= pd.DataFrame()
    with open('kycquestions.csv') as f:
        st.download_button('Download KYC Questions.csv', f,file_name='kycquestions.csv')
        st.write("NOTE: You can download the KYC Extraction questions CSV and modify like Scope, customer, expected answer and upload")
    st.markdown("---")
    spectra = st.file_uploader("Upload file", type={"csv", "txt"})
    if spectra is not None:
        spectra_df = pd.read_csv(spectra)
    else:
        spectra_df=pd.read_csv('kycquestions.csv')
    st.dataframe(spectra_df, height=None, width=None)
    spectra_df2=spectra_df[spectra_df["PoCScope"]=='X']
    st.write("Number of questions: ",spectra_df.shape[0])
    st.write("Number of questions filtered for Demo ",spectra_df2.shape[0])
    #st.write("GenAI  * * * * * * * * * * * * * * * * * * * * * * * * * * * * * ")
    st.markdown("---")
    parameters = {"decoding_method": "greedy","max_new_tokens": 50,"repetition_penalty": 1,"temperature":1}
    ##Outptu structure       
    dict = {'Question':[],
            'Response':[]
        }
    dfDataExtraction = pd.DataFrame(dict)
    QuestionsForDemoScope=0
    #modelid = "ibm/granite-13b-chat-v2"
    modelid = "ibm/granite-13b-instruct-v2"
    for ind in spectra_df.index: 
        if spectra_df["PoCScope"][ind]=='X':
            QuestionsForDemoScope=QuestionsForDemoScope+1
            discoveryQuestionTmp=spectra_df["Question"][ind]
            discoveryQuestion = discoveryQuestionTmp.replace("?", " ") +  customerName + "?"
            ##st.write(discoveryQuestion)
            try:
            # query Discovery results enriched_text.entities:(text:IBM,type:Company)
                response = discovery.query(project_id=project_id,
                                        collection_ids=[collection_id],
                                        #filter="enriched_text.entities.text:"+customerName+",enriched_text.entities.type:Company",
                                        natural_language_query=discoveryQuestion,
                                        count=4).get_result()
            except ConnectionError:
                print("Lookup Error")
            json_d=json.dumps(response, indent=4)
            f = open('data.json', 'w')
            f.write(json_d)
            #st.write(json_d)
            consolidatedText=""
            if len(response["results"])>0:
                with open('data.json') as data_file:
                    x=0
                    data = json.load(data_file)
                    for y in range(0,len(data['results'])):
                        for z in range(0,len(data['results'][y]['document_passages'])):
                            consolidatedText = consolidatedText + "  " + data['results'][y]['document_passages'][z]["passage_text"]
                            consolidatedTextTmp1 = consolidatedText.replace("<em>", " ")
                            consolidatedTextTmp2 = consolidatedTextTmp1.replace("</em>", " ")
                            consolidatedText = ""
                            consolidatedText = consolidatedTextTmp2.replace("\n", " ")
                    #st.write ("End of Question * * * * * * * * * * * ",ind)
                    #st.write(consolidatedText)
                    prompt_input = "Given the below context, please answer my question., \nQuestion:" + discoveryQuestion + " \nContext:" + consolidatedText + " \nAnswer:"
                    prompt = Prompt(access_token, watsonxai_project_id)
                    pd.set_option('display.max_colwidth', None)
                    pd.set_option("display.max_rows", 999)
                    # Model 1 * * * * * * * * * * * * * * * * * *
                    ModelResponse1 = prompt.generate(prompt_input, modelid,parameters )
                    genAiResponse1=""
                    if ModelResponse1.status_code == 200:
                        genAiResponse1=ModelResponse1.json()["results"][0]["generated_text"]
                    else:
                        genAiResponse1=ModelResponse1.text
                    #st.write(genAiResponse1)    
                    ## construct output for each question
                    data = {    'Question': discoveryQuestion,
                                'Response':genAiResponse1
                            }
                    dfDataExtraction = dfDataExtraction._append(data, ignore_index = True)
    st.markdown("---")  
    st.dataframe(dfDataExtraction, height=None, width=None)
    st.markdown("---")
       

    