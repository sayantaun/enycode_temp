# KYC data extraction
Know Your Customer (KYC) Customer identification program follows Customer due diligence (CDD), Enhanced due diligence  (EDD) and ongoing monitoring and risk assessment. Financial institutes especially Banks spend time to perform KYC validation by engaging team of consultants who validate the information from various data sources with the help automated tools and submits a consolidated reports for further processing.

This demo demonstrates how LLMs can be trained to extract required information from multiple documents and specific information from each document, train for population of data into pre-defined format or template.  Information like Company or individua customer details, Financial status, people involved, any fraudulent incidents by analyzing various sources of data  like Financial Reports, Company Website, Information available in News and Public Domain and extracts relevant information and summarizes the same. This reduces the quality time the spent n on KYC validation. 

![KYCdataExtraction](https://media.github.ibm.com/user/38533/files/98cede90-7728-49a3-8915-cd4bef69b841)

## Pre-requisites

1. A watsonx.ai instance on IBM cloud ([get a watsonx trial account](https://dataplatform.cloud.ibm.com/registration/stepone?context=wx)).
2. A watsonx Discovery service on IBM cloud.
    - 2.1 Create a project in Watson Discovery
    - 2.2 Create a Collection in the project to upload KYC documents 	
    - 2.3 Copy ProjectID and CollectionID from Project settings
    
3. Add .env file to your application folder and add env variable

4. Steps to create IBM Cloud API key
    - 4.1 In the IBM Cloud console, go to Manage > Access (IAM) > API keys
    - 4.2 Click Create an IBM Cloud API key
    - 4.3 Enter a name and description for your API key 
    - 4.4 Click Create
    - 4.5 Then, click Show to display the API key. Or, click Copy to copy and save it for later, or click Download
<!--       ![image](https://media.github.ibm.com/user/38533/files/5d807772-1bc8-4287-948f-dde8b9b9766e) -->

5. Add project id to LLM call

    > Steps to create project_id (skip 5.1 to 5.3 for watsonx trial account)

    - 5.1 In IBM Cloud, [Set up IBM Cloud Object Storage for use with IBM watsonx](https://dataplatform.cloud.ibm.com/docs/content/wsj/console/wdp_admin_cos.html?context=wx&audience=wdp)
    - 5.2 [Set up the Watson Studio and Watson Machine Learning services](https://dataplatform.cloud.ibm.com/docs/content/wsj/getting-started/set-up-ws.html?context=wx&audience=wdp)
    - 5.3 Create a Project from IBM watsonx console - https://dataplatform.cloud.ibm.com/projects/?context=wx
    - 5.4 (Optional step: add more collaborators) Open the Project > Click on **Manage** tab > Click on **Access Control** from the **Manage** tab > 		Click [Add collaborators](https://dataplatform.cloud.ibm.com/docs/content/wsj/getting-started/collaborate.html?context=wx&audience=wdp#add-collaborators) > **Add Users** > Choose **role** as **Admin** > Click **Add**
    - 5.5 Click on **Manage** tab > Copy the **Project ID** from **General**

## watsonx.ai api server url

```
WX_URL = https://us-south.ml.cloud.ibm.com
WX_PROJECT_ID = <your watsonx.ai project_id>
IBM_CLOUD_API_KEY = <your IBM Cloud API key for watsonx.ai>
```

## watsonx Discovery instance connection

```
WDS_APIKEY=<your watson Discovery API Key> 
WDS_URL=<your watson Discovery  instance url> 
WDS_PROJECT_ID=<your watson Discovery project Id>  
WDS_COLLECTION_ID=your watson Discovery Collection Id>  
IAM_KEY=<IAM APIKey generated in Step 4> 
WML_URL=<Watson MAchine Learning URL> 
WATSONX_PROJECT_ID=<Watsonx.ai project Id>
``` 

It is assumed that Python3+ is installed or download from <https://www.python.org/downloads/>.

## Run application locally
	
- Clone repository locally
  
- Install python dependency  
  ```
  pip install -r requirements.txt
  ```
- export environment variables
  ```
  export $(grep -v '^#' .env | xargs)
  ```
  
- Run the app
  ```
  streamlit run app.py
  ```
  
## Deploy on Cloud
### Deployment Instructions

To deploy the application on Code Engine, build a container image and deploy it.

1. Build Container Image by running the following command in terminal,
    ```bash
    podman build --platform=linux/amd64 -t kycde-application:1.0 .
    ```
    >Note: The `--platform=linux/amd64` flag is required if you are building the image from a M1 silicon MacBook.

2. Create a namespace in [IBM Cloud Container Registry](https://cloud.ibm.com/registry/start).
    <details><summary><strong>Install Container Registry Plugin Command</strong></summary>

    ```bash
    ibmcloud plugin install container-registry -r 'IBM Cloud'
    ```
    </details>

    ```bash
    ibmcloud login --sso
    ```

    ```bash
    ibmcloud target -g Default -r us-east
    ```
    
    ```bash
    ibmcloud cr region-set us-south
    ```

    ```bash
    ibmcloud cr namespace-add <my_namespace>
    ```
    
    ```bash
    ibmcloud cr login
    ```

3. Tag the image with registry namespace prefix.
    ```bash
    podman tag kycde-application:1.0 us.icr.io/<my_namespace>/kycde-application:1.0
    ```

4. Push the image to IBM Cloud Container Registry.
    ```bash
    podman push us.icr.io/<my_namespace>/kycde-application:1.0
    ```

5. Create a Code Engine Project.
    <details><summary><strong>Install Code Engine Plugin Command</strong></summary>

    ```bash
    ibmcloud plugin install code-engine
    ```
    </details>
    
    ```bash
    ibmcloud ce project create --name <Project Name>
    ```

6. Select the newly created project.
    ```bash
    ibmcloud ce project select --name <Project Name>
    ```

7. Create the secrets in Code Engine. Create a `.env` file in the root directoy of the repo and add the environment variables `API_KEY`, `IBM_CLOUD_API_KEY` & `PROJECT_ID` and save it.
    
    - Run the following command in terminal to copy the env variables to `.env` file:
        ```bash
        env | grep API_KEY >> .env && env | grep WX_ >> .env  >> .env
        ```

    - You should see a **.env** file created with content:
      ```
      WDS_APIKEY=<your watson Discovery API Key> 
      WDS_URL=<your watson Discovery  instance url> 
      WDS_PROJECTID=<your watson Discovery project Id>  
      WDS_COLLECTION_ID=your watson Discovery Collection Id>  
      IAM_KEY=<IAM APIKey generated in Step 4> 
      WML_URL=<Watson MAchine Learning URL> 
      ```

    - Create secret in Code Engine with this **.env** file.
        ```bash
        ibmcloud ce secret create --name fast-api-secrets --from-env-file .env
        ```

8. Create another secret to access the IBM Cloud Container Registry. This will be your `IBM_CLOUD_API_KEY` that will be used as Image Pull secret by the Code Engine.

    ```bash
    ibmcloud ce secret create --format registry --name us-icr-io-creds --server us.icr.io --username iamapikey --password $IBM_CLOUD_API_KEY
    ```

    ```

9. You will see an URL to access the Application.

- Example URL: <https://kyc-data-validation.1go4konbwq1q.us-east.codeengine.appdomain.cloud/>

---

## Demo Instructions

You can now access the application from your browser at the following URL.
http://localhost:8056
	
- Upload Company Profile document [Sample Company Overview (BROOKHOUSE AEROSPACE LIMITED)](/BROOKHOUSE_AEROSPACE_LIMITED_overview.pdf)
Optionally you can download Questions in csv format and customize the questionaire and options and upload. 
Please not that the models in application are Zero-shot trained. You ay need to tune the model and updload more document to find accurate answers for non default questions. 

<img width="754" alt="kycdocs" src="https://media.github.ibm.com/user/38533/files/d07d713a-1544-4467-a8a7-dfad589e6823">

- Application shows answers for marked questions
Note: Ingestion of documents to Watson Discovery takes few miniutes, you may refresh the application before running the questions.

- Alternately you can download the Questions [Sample Questionaire](/kycquestions.csv) and customize the questions and uoload the csv again.
<img width="749" alt="KYCQustions1" src="https://media.github.ibm.com/user/38533/files/610e1a67-1ae6-4b54-beae-16d57f2a924c">
<img width="783" alt="KYCQuestions2" src="https://media.github.ibm.com/user/38533/files/7fc5c5fe-b187-4e28-ab5e-345973a5bcfa">


