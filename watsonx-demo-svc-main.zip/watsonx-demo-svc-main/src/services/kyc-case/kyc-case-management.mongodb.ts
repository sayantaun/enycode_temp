import {BehaviorSubject, Observable, Subject} from "rxjs";
import {
    ApproveCaseModel,
    createNewCase,
    CustomerModel,
    CustomerRiskAssessmentModel,
    DocumentContent,
    DocumentModel,
    DocumentRef,
    DocumentStream,
    isDocumentContent,
    isDocumentRef,
    KycCaseChangeEventModel,
    KycCaseChangeType,
    KycCaseModel,
    KycCaseSummaryModel,
    NegativeScreeningModel,
    ReviewCaseModel
} from "src/models";
import {KycCaseManagementApi} from "./kyc-case-management.api";
import {documentManagerApi, DocumentManagerApi} from "../document-manager";
import {Collection, Db, GridFSBucket, ObjectId, WithId} from "mongodb";
import Stream, {PassThrough} from "stream";
import {streamToBuffer, urlToStream} from "../../utils";

interface DocumentRefModel {
    id?: string;
    name: string;
    path: string;
}

export class KycCaseManagementMongodb implements KycCaseManagementApi {
    private readonly cases: Collection<KycCaseModel>
    private readonly documents: Collection<DocumentRefModel>
    private readonly bucket: GridFSBucket;

    subject: BehaviorSubject<KycCaseModel[]>;
    changeSubject: Subject<KycCaseChangeEventModel>;

    constructor(
        private readonly documentManagerService: DocumentManagerApi = documentManagerApi(),
        db: Db,
    ) {
        this.cases = db.collection('kyc-cases');
        this.documents = db.collection('kyc-case-document')
        this.bucket = new GridFSBucket(db, {bucketName: 'kyc-case-documents'})

        this.subject = new BehaviorSubject([])
        this.changeSubject = new Subject()
    }

    notifyKycCases(event: KycCaseChangeType) {
        return (kycCase: KycCaseModel): KycCaseModel => {
            this.changeSubject.next({kycCase, event});

            return kycCase;
        }
    }

    async listCases(): Promise<KycCaseModel[]> {
        const result = this.cases
            .find({})
            .map((doc: WithId<KycCaseModel>) => Object.assign({}, doc, {id: doc._id}))

        return result.toArray()
    }

    subscribeToCases(skipQuery?: boolean): Observable<KycCaseModel[]> {
        if (!skipQuery) {
            // TODO???
        }

        return this.subject;
    }

    async getCase(id: string): Promise<KycCaseModel> {
        const result = await this.cases.findOne(new ObjectId(id))

        return Object.assign(
            {},
            result,
            {
                id: result._id,
            })
    }

    async createCase(customer: CustomerModel): Promise<KycCaseModel> {

        const document: KycCaseModel = createNewCase(customer);

        return this.cases.insertOne(document)
            .then(result => result.insertedId.toString())
            .then(caseId => Object.assign(
                {},
                document,
                {
                    id: caseId
                }
            ))
            .then(this.notifyKycCases('created').bind(this))
    }

    async addDocumentToCase(caseId: string, documentName: string, document: DocumentRef | DocumentContent | DocumentStream, pathPrefix?: string): Promise<DocumentModel> {
        const currentCase = await this.getCase(caseId);

        const content = await this.loadDocument(document);

        const newDoc = await this.documentManagerService.uploadFile({
            name: documentName,
            parentId: caseId,
            content: {buffer: content},
            context: 'kyc-case',
        });

        const caseDoc: DocumentModel = Object.assign({}, newDoc, {path: `${pathPrefix}${newDoc.path}`, content: Buffer.from('')});

        const documents: DocumentModel[] = currentCase.documents.concat(caseDoc)

        await this.updateCase(caseId, {documents})

        const documentResult = await this.documents
            .insertOne({name: caseDoc.name, path: caseDoc.path})

        const documentId = documentResult.insertedId;

        await new Promise<boolean>((resolve, reject) => {
            bufferToStream(content)
                .pipe(this.bucket.openUploadStream(`${documentId}-${documentName}`, {
                    chunkSizeBytes: 1048576,
                    metadata: {
                        documentId,
                        name: documentName,
                    }
                }))
                .on('finish', () => resolve(true))
                .on('error', err => reject(err))
        })

        return Object.assign(caseDoc, {id: documentId.toString()})
    }

    async loadDocument(document: DocumentRef | DocumentContent | DocumentStream): Promise<Buffer> {
        if (isDocumentContent(document)) {
            return document.content;
        }

        const stream: Stream = isDocumentRef(document)
            ? await urlToStream(document.url)
            : document.stream;

        return streamToBuffer(stream);
    }

    async removeDocumentFromCase(caseId: string, documentId: string): Promise<KycCaseModel> {
        const currentCase = await this.getCase(caseId);

        const documents: DocumentModel[] = currentCase.documents.slice()

        const documentIndex: number = documents.map(val => val.id).indexOf(documentId);

        // remove the document
        documents.splice(documentIndex, 1);

        return this.documents
            .deleteOne(new ObjectId(documentId))
            .then(() => this.updateCase(caseId, {documents}))
    }

    async getDocument(id: string): Promise<DocumentModel> {
        const documentRef: WithId<DocumentRefModel> = await this.documents
            .findOne(new ObjectId(id))

        const fileId = `${documentRef.id}-${documentRef.name}`

        const content = await streamToBuffer(this.bucket.openDownloadStreamByName(fileId))

        return Object.assign(
            {},
            documentRef,
            {
                id: documentRef._id,
                content
            })
    }

    async updateCase(id: string, updates: Partial<KycCaseModel>) : Promise<KycCaseModel> {
        const result = await this.cases
            .updateOne(new ObjectId(id), {$set: updates})

        return this.getCase(id)
            .then(this.notifyKycCases('updated').bind(this))
    }

    async reviewCase(reviewCase: ReviewCaseModel): Promise<KycCaseModel> {
        const updates: Partial<KycCaseModel> = {
            status: reviewCase.customerOutreach ? 'CustomerOutreach' : 'Pending'
        };

        return this.updateCase(reviewCase.id, updates)
    }

    async approveCase(input: ApproveCaseModel): Promise<KycCaseModel> {
        return this.updateCase(input.id, {status: 'Pending'})
    }

    async processCase(id: string): Promise<KycCaseModel> {
        const updates: Partial<KycCaseModel> = {
            status: 'Pending',
            negativeScreeningComplete: false,
            counterpartyNegativeScreeningComplete: false,
            customerRiskAssessmentComplete: false,
            caseSummaryComplete: false,
        }

        return this.updateCase(id, updates);
    }

    async deleteCase(id: string): Promise<KycCaseModel> {
        const kycCase: KycCaseModel = await this.getCase(id);

        return this.cases.deleteOne(new ObjectId(id))
            .then(() => kycCase)
            .then(this.notifyKycCases('deleted').bind(this))
    }

    async updateCustomerRiskAssessment(id: string, customerRiskAssessment: CustomerRiskAssessmentModel): Promise<KycCaseModel> {
        const currentCase: KycCaseModel = await this.getCase(id);

        const updates: Partial<KycCaseModel> = {
            customerRiskAssessment,
            customerRiskAssessmentComplete: true,
            status: this.getUpdatedStatus(currentCase),
        };

        return this.updateCase(id, updates);
    }

    async updateNegativeNews(id: string, negativeScreening: NegativeScreeningModel): Promise<KycCaseModel> {
        const currentCase: KycCaseModel = await this.getCase(id);

        const updates: Partial<KycCaseModel> = {
            negativeScreening,
            negativeScreeningComplete: true,
            status: this.getUpdatedStatus(currentCase),
        };

        return this.updateCase(id, updates);
    }

    async updateCounterpartyNegativeNews(id: string, counterpartyNegativeScreening: NegativeScreeningModel): Promise<KycCaseModel> {
        const currentCase: KycCaseModel = await this.getCase(id);

        const updates: Partial<KycCaseModel> = {
            counterpartyNegativeScreening,
            counterpartyNegativeScreeningComplete: true,
            status: this.getUpdatedStatus(currentCase),
        };

        return this.updateCase(id, updates);
    }

    async updateCaseSummary(id: string, caseSummary: KycCaseSummaryModel): Promise<KycCaseModel> {
        const currentCase: KycCaseModel = await this.getCase(id);

        const updates: Partial<KycCaseModel> = {
            caseSummary,
            caseSummaryComplete: true,
            status: this.getUpdatedStatus(currentCase),
        }

        return this.updateCase(id, updates)
    }

    getUpdatedStatus(kycCase: KycCaseModel): string {
        if (kycCase.status !== 'Pending') {
            return kycCase.status;
        }

        return kycCase.caseSummaryComplete && kycCase.negativeScreeningComplete && kycCase.counterpartyNegativeScreeningComplete && kycCase.customerRiskAssessmentComplete
            ? 'Completed'
            : 'Pending';
    }

    listDocuments(): Promise<DocumentModel[]> {
        const result = this.documents
            .find({})
            .map((doc: WithId<DocumentModel>) => Object.assign({}, doc, {id: doc._id}))

        return result.toArray()
    }

    async deleteDocument(id: string): Promise<DocumentModel> {
        const kycCaseDocument = await this.getDocument(id);

        await this.cases.deleteOne(new ObjectId(id))

        return kycCaseDocument
    }

    watchCaseChanges(): Observable<KycCaseChangeEventModel> {
        return this.changeSubject;
    }

    watchCase(id: string): Observable<KycCaseModel> {
        const subject: BehaviorSubject<KycCaseModel> = new BehaviorSubject<KycCaseModel>(undefined);

        console.log('Watching case: ' + id)
        this.getCase(id).then(kycCase => {
            subject.next(kycCase);

            this.changeSubject.subscribe({
                next: event => {
                    if (event.kycCase?.id === id) {
                        console.log('Updated case: ', {kycCase: event.kycCase})
                        subject.next(event.kycCase);
                    }
                }
            })
        });

        return subject.asObservable();
    }

}

export const bufferToStream = (buffer: Buffer): Stream => {
    const bufferStream = new PassThrough();

    bufferStream.end(buffer);

    return bufferStream;
}
