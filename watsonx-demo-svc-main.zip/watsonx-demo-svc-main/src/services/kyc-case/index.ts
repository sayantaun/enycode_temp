import {Provider} from "@nestjs/common";

import {KycCaseManagementMock} from "./kyc-case-management.mock";
import {KycCaseManagementApi} from "./kyc-case-management.api";
import {NegativeNewsApi, negativeNewsProvider} from "../negative-news";
import {cloudantBackend, CloudantBackendConfig} from "./cloudant.backend";
import {KycCaseManagementCloudant} from "./kyc-case-management.cloudant";
import {documentManagerApi} from "../document-manager";
import {mongodbClient, mongodbConfig} from "./mongodb.backend";
import {KycCaseManagementMongodb} from "./kyc-case-management.mongodb";

export * from './kyc-case-management.api';

const cloudantBackendConfig = cloudantBackend()
const mongoBackendConfig = mongodbConfig()

let _instance: Promise<KycCaseManagementApi>;
export const kycCaseProvider: Provider = {
    provide: KycCaseManagementApi,
    useFactory: async (negativeNews: NegativeNewsApi): Promise<KycCaseManagementApi> => {
        if (_instance) {
            return _instance;
        }

        return _instance = new Promise(async (resolve, reject) => {
            if (mongoBackendConfig.username && mongoBackendConfig.password && mongoBackendConfig.connectString) {
                console.log('Loading mongodb backend...');
                resolve(new KycCaseManagementMongodb(documentManagerApi(), await mongodbClient()))
            } else if (cloudantBackendConfig.apikey && cloudantBackendConfig.url) {
                console.log('Loading cloudant backend...')
                resolve(new KycCaseManagementCloudant(documentManagerApi(), cloudantBackendConfig as CloudantBackendConfig))
            } else {
                console.log('No database configuration found. Using mock KycCaseManagement instance...')
                resolve(new KycCaseManagementMock(negativeNews))
            }
        })
    },
};
