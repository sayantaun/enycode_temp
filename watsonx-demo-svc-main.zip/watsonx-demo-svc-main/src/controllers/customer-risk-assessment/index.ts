export * from './customer-risk-assessment.controller';
