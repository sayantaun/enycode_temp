export interface GreetingModel {
    greeting: string
}
