export * from './greeting.model';
export * from './kyc-case.model';
export * from './data-extraction.model';
export * from './form-option.model';

export type FileUploadContext = 'data-extraction' | 'kyc-case';
