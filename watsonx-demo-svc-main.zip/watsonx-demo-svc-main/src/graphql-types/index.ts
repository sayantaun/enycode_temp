export * from './greetings.graphql';
export * from './kyc-case.graphql';
export * from './data-extraction.graphql';
export * from './form-option.graphql';
