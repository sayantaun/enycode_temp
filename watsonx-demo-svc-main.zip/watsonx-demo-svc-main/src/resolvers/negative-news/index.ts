export * from './negative-news.resolver';
