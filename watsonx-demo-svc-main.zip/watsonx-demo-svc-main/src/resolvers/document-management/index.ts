export * from './document-management.resolver';
