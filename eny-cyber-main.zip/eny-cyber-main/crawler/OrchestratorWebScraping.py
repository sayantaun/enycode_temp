# -*- coding: utf-8 -*-
"""
@author: Surya Deep Singh
"""

import DuckDuckGoWebScraping
import GooNeWebScraping
import NateWebScraping
import NaverWebScraping
import uvicorn
from fastapi import FastAPI, HTTPException
app = FastAPI(version="3.0.2")

def OrcestratorWebScrapperText(search_engine,search_query,language):
    if search_engine.strip().lower() == 'duckduckgo':
        DuckDuckGoWebScraping.DuckDuckGoWebScrapingText(search_engine,search_query,language)
    #if search_engine.strip().lower() == 'goo':
       # GooNeWebScraping.GooNeWebScrapingText(search_engine,search_query,language)
    if search_engine.strip().lower() == 'nate':
        NateWebScraping.NateWebScrapingText(search_engine,search_query,language)
    if search_engine.strip().lower() == 'naver':
        NaverWebScraping.NaverWebScrapingText(search_engine,search_query,language)
      

@app.post("/result")
async def get_result(query_body: dict):
    search_engine = query_body.get("search_engine")
    search_query = query_body.get("search_query")
    language = query_body.get("language")
    try:
        #lst  = ['nate','duckduckgo','naver']
        #for search_engine in lst:
         #   print("@#$#%#$%#%%%#%$#%#$%#%#%!@#!#@#$",search_engine )
         OrcestratorWebScrapperText(search_engine,search_query,language)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
if __name__ == "__main__":
    uvicorn.run("OrchestratorWebScraping:app", host ='127.0.0.1', port=5555, log_level="info")
