# -*- coding: utf-8 -*-
"""
@author: Surya Deep Singh
"""

import requests
from bs4 import BeautifulSoup
import re
import os
import iFrameWebScraping
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd
def extract_numbers(file_name):
  numbers = re.findall(r'\d+', file_name)
  numbers = numbers[0]
  return int(numbers)

def getFileName(folder_path):
    file_list = os.listdir(folder_path)
    txt_files = [file for file in file_list if file.endswith('.txt')]
    if txt_files:
        numbers = []
        for file_name in txt_files:
            numbers.append(extract_numbers(file_name))
        count = sorted(numbers, reverse=True)
        count = count[0]+1
        return int(count)
    return int(1)

def all_pages(url):
    
    driver = webdriver.Chrome()
    driver.get(url)
    soup_list = []
    counter = 0
    while counter < 5:
        try:
            counter += 1
            wait = WebDriverWait(driver, 10)  
            next_button = wait.until(EC.presence_of_element_located((By.XPATH, '//button[@class="btn_next"]')))
            soup = BeautifulSoup(driver.page_source, 'html.parser')
            soup_str = str(soup)
            soup_list.append(soup_str)
            next_button.click()
        except Exception as e:
            print("An error occurred: ", e)
    driver.quit()
    final_text = ' '.join(soup_list)
    split_data = final_text.split('c-card class')
    dates = []
    links = []
    count = 1
    for data in range(1,len(split_data)):
        count +=1
        new_soup = BeautifulSoup(split_data[data], "html.parser")
        #new_soup = BeautifulSoup(cc, "html.parser")
        link = new_soup.find_all(attrs={"data-href": True})
        for element in link:
            data_href_value = element['data-href']
            if data_href_value:
                links.append(str(data_href_value))
            else:
                links.append('')
            break
        gem_subdesc = new_soup.find(class_="gem-subdesc")
        if gem_subdesc:
            date = gem_subdesc.text.strip()
            dates.append(str(date))
        else:
            pattern = r'\d{4}\.\d{2}\.\d{2}'
            matches = re.findall(pattern, str(new_soup))
            if matches:  # Check if the list is not empty
                dates.append(str(matches[0]))
            else:
                dates.append('')
    df = pd.DataFrame()
    df['links'] = links
    df['dates'] = dates
    df = df[(df['dates'] != '') & (df['links'] != '')]
    df.reset_index(drop=True, inplace=True)
    pattern = r'\d{4}\.\d{2}\.\d{2}'
    df = df[df['dates'].str.contains(pattern, regex=True, na=False)]
    from datetime import datetime, timedelta
    six_months_ago = datetime.now() - timedelta(days=6*30)
    df = df[pd.to_datetime(df['dates']) > six_months_ago]
    df.reset_index(drop=True, inplace=True)
    for i in list(set(links)):
        if ('wikipedia' in i) or ('linkedin' in i):
            new_df = pd.DataFrame({'links': [i],'dates': ['']})
            df = df.append(new_df, ignore_index=True)
    df = df.drop_duplicates()
    df.reset_index(drop=True, inplace=True)
    df['dates'] = df['dates'].str.replace('.', '-')
    df['links'] = df['links'].apply(lambda x: 'https://' + x if not x.startswith('https://') else x)
    df.reset_index(drop=True, inplace=True)
    return df

def NateWebScrapingText(search_engine,search_query,language):
    folder_path = 'C:/IBM_WORK/IBM_ISL/web scraping ey test'
    file_count = getFileName(folder_path)
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36"
    }
    #search_query = str('UNC3944')
    url = str('https://search.daum.net/nate?q='+str(search_query))
    all_pages_df = all_pages(url)
    tags_to_extract = ['p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'strong', 'em', 'b', 'i', 'small', 'mark','sub', 'sup']
    final_op = []
    for link, date in zip(all_pages_df['links'],all_pages_df['dates']):
        try:
            response = requests.get(link,headers=headers)
            soup_link = BeautifulSoup(response.text, "html.parser")
            body_tag = soup_link.body
            extracted_text = []
            for tag in body_tag.find_all():
                if tag.name in tags_to_extract:
                    textt = str(tag.text)
                    textt = textt.strip().replace('/n','')
                    if len(textt) > 0:
                        extracted_text.append(textt)
            result = ' '.join(extracted_text)
            if len(result.strip()) > 0:
                final_text = str(result) + "\n" + "Website_Date : " +str(date)  + "\n" + "Website_Link : " +str(link)
                final_op.append(final_text)
                #print(final_text)
                with open(str(folder_path)+'/'+str('file_nate_'+str(file_count))+'.txt', 'w', encoding='utf-8') as f:
                    f.write(str(final_text).strip())
                file_count += 1
                print("######################################################################################")
            else:
                result = iFrameWebScraping.iFrameWebscrapingText(link)
                final_text = str(result) + "\n" + "Website_Date : " +str(date)  + "\n" + "Website_Link : " +str(link)
                final_op.append(final_text)
                #print(final_text)
                with open(str(folder_path)+'/'+str('file_nate_'+str(file_count))+'.txt', 'w', encoding='utf-8') as f:
                    f.write(str(final_text).strip())
                file_count += 1
                print("$$$$$$$$$$$$$$$$$$$$$$$$$$$")
        except:
            try:
                result = iFrameWebScraping.iFrameWebscrapingText(link)
                final_text = str(result) + "\n" + "Website_Date : " +str(date)  + "\n" + "Website_Link : " +str(link)
                final_op.append(final_text)
                #print(final_text)
                with open(str(folder_path)+'/'+str('file_nate_'+str(file_count))+'.txt', 'w', encoding='utf-8') as f:
                    f.write(str(final_text).strip())
                file_count += 1
                print("************************")
            except:
                pass
            