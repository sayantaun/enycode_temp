# -*- coding: utf-8 -*-
"""
Created on Tue Nov  7 18:32:46 2023

@author: Surya Deep Singh
"""




from selenium import webdriver
from bs4 import BeautifulSoup

def iFrameWebscrapingText(url):
    try:
        driver = webdriver.Firefox()
        #url = 'https://blog.naver.com/mandiantkorea'
        #url = 'https://blog.naver.com/mandiantkorea/223215058229'
        driver.get(url)
        driver.switch_to.frame("mainFrame")
        soup = BeautifulSoup(driver.page_source, 'html.parser')
        tags_to_extract = ['p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'strong', 'em', 'b', 'i', 'small', 'mark', 'del', 'ins', 'sub', 'sup']
        extracted_text = []
        for tag in soup.find_all():
            if tag.name in tags_to_extract:
                textt = str(tag.text)
                textt = textt.strip().replace('/n','')
                if len(textt) > 0:
                    extracted_text.append(textt)
        result = ' '.join(extracted_text)
        driver.switch_to.default_content()
        driver.quit()
        return result 
    except:
        return ''
   