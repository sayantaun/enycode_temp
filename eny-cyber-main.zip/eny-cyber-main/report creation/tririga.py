from langchain.text_splitter import CharacterTextSplitter
from langchain.vectorstores import Chroma
from langchain.embeddings import HuggingFaceEmbeddings
from ibm_watson_machine_learning.metanames import GenTextParamsMetaNames as GenParams
from ibm_watson_machine_learning.foundation_models import Model
from ibm_watson_machine_learning.foundation_models.utils.enums import DecodingMethods
from ibm_watson_machine_learning.foundation_models.extensions.langchain import WatsonxLLM
from langchain.chains import RetrievalQA

class RAG:
    def __init__(self,query):
        self.query=query

    def gen_answer(self):
        # Chunk the input content
        print('1. Get input parameters')
        wx_url ="https://us-south.ml.cloud.ibm.com"
        wx_apikey = "VS7ZxaaSW-YKAY78Ocfi1WKUKZjYvD4MiSbTdjlJtrnt"  # Masked
        wx_project_id = "68abd89f-1eb6-471c-9f8d-d1e25520cfbf"  # Masked
        wx_model_id = "ibm/granite-13b-chat-v2"

        # Input text content that need to be queried

        print("1.1 Loading sample input text")
        file = open("./sample.txt", "r")
        wx_inputText = file.read()
        # list_text=wx_inputText.split("smuggling.")
        # print(wx_inputText)
        file.close()

        print("1.2 Loading sample input query")
        wx_inputQuery = self.query

        credentials = {
            "url": wx_url,
            "apikey": wx_apikey
        }
        print("2. Chunk the input text")
        text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
        # text_splitter = CharacterTextSplitter(
        #     separator="\n\n",
        #     chunk_size=1000,
        #     chunk_overlap=200,
        #     length_function=len,
        #     is_separator_regex=False,
        # )
        texts = text_splitter.create_documents([wx_inputText])

        print("3. Create embeddings")
        embeddings = HuggingFaceEmbeddings()
        docsearch = Chroma.from_documents(texts, embeddings)

        print("4. Create instance of LLM")
        # LLM parameters
        parameters = {
            GenParams.DECODING_METHOD: DecodingMethods.GREEDY,
            GenParams.MIN_NEW_TOKENS: 1,
            GenParams.MAX_NEW_TOKENS: 100,
            GenParams.STOP_SEQUENCES: ["<|endoftext|>"]
        }

        # watsonx.ai connection details
        watsonx_model = Model(
            model_id=wx_model_id,
            credentials=credentials,
            project_id=wx_project_id,
            params=parameters
        )

        watsonx_llm = WatsonxLLM(model=watsonx_model)

        print("5. Invoke LLM")
        # Invoke LLM via Langchain

        wx_inputQuery={"query": wx_inputQuery}
        qa = RetrievalQA.from_chain_type(llm=watsonx_llm, chain_type="stuff", retriever=docsearch.as_retriever())
        output = qa.invoke(wx_inputQuery)
        print(output)
