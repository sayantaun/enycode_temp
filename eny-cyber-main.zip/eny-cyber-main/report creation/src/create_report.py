from langchain import hub
from langchain.document_loaders import DirectoryLoader,PyPDFLoader
from langchain.schema import StrOutputParser
from langchain.schema.runnable import RunnablePassthrough
from langchain.text_splitter import CharacterTextSplitter#,SentenceTransformersTokenTextSplitter,SpacyTextSplitter
from langchain.vectorstores import Chroma
from ibm_watson_machine_learning.foundation_models.extensions.langchain import WatsonxLLM
from ibm_watson_machine_learning.metanames import GenTextParamsMetaNames as GenParams
from ibm_watson_machine_learning.foundation_models import Model
from ibm_watson_machine_learning.foundation_models.utils.enums import ModelTypes, DecodingMethods
from langchain.embeddings.sentence_transformer import SentenceTransformerEmbeddings
from langchain.chains import RetrievalQA
import glob
from cos_connect import CosOperations
from dotenv import load_dotenv
import os
import time
import shutil
class CreateReport:
    def __init__(self, threat):
        threat = threat.upper()
        self.threat = threat.strip()
        print("threat:",self.threat)
        load_dotenv("../environ.env")
        self.api_key = os.environ["API_KEY"]
        print(self.api_key)
        self.project_id = os.environ["WX_PROJECT_ID"]
        self.cos=CosOperations()

    def create_vector_db(self):
        print("Loading files into a vector DB...")
        start = time.time()
        loader = DirectoryLoader("../crawled")
        docs = loader.load()

        # text_splitter = CharacterTextSplitter(chunk_size=7500, chunk_overlap=200)
        text_splitter = CharacterTextSplitter(
            separator="\n",
            chunk_size=3700,
            chunk_overlap=150,
            length_function=len
        )

        splits = text_splitter.split_documents(docs)
        # print(splits)
        print(len(splits))
        for split in splits:
            #print("doc-----",split.page_content)
            if "AES256" in split.page_content:
                print("doc-----",split.page_content)


        end = time.time()
        print(f"Vector DB created in {end - start} seconds")

    def create_report(self):
        embedding_function = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")
        chroma_directory="../chroma"
        # Chroma(persist_directory=persist_directory, embedding_function=embeddings)
        # vectorstore = Chroma(persist_directory=chroma_directory,embedding_function=embedding_function)
        loader = DirectoryLoader("../crawled")
        docs = loader.load()
        text_splitter = CharacterTextSplitter(
            separator="\n",
            chunk_size=3700,
            chunk_overlap=150,
            length_function=len
        )

        splits = text_splitter.split_documents(docs)
        # docs_n = []
        # for split in splits:
        #     docs_n.append(split.page_content)
        vectorstore=Chroma.from_documents(splits, embedding_function)
        retriever = vectorstore.as_retriever()


        print("Starting inferencing...")
        start = time.time()
        params = {
            GenParams.MAX_NEW_TOKENS: 1200,
            GenParams.MIN_NEW_TOKENS: 1,
            GenParams.DECODING_METHOD: DecodingMethods.GREEDY,
            GenParams.TEMPERATURE: 0.1,
            GenParams.TOP_K: 10,
            GenParams.TOP_P: 0.9,
            GenParams.REPETITION_PENALTY: 1.0
        }
        credentials = {
            'url': "https://us-south.ml.cloud.ibm.com",
            'apikey' : self.api_key
        }
        print("credentials-----",credentials)
        project_id = self.project_id


        llama_model = Model(
            model_id="meta-llama/llama-2-70b-chat",#'google/flan-ul2',#
            credentials=credentials,
            params=params,
            project_id=project_id)
        retrieval_llm = WatsonxLLM(model=llama_model)

        def format_docs(docs):
            return "\n\n".join(doc.page_content for doc in docs)



        # with open("../prompts/rag.prompt", "r") as f:
        #     prompt = f.read()
        # rag_chain = RetrievalQA.from_chain_type(
        #     retrieval_llm,
        #     retriever=vectorstore.as_retriever(),
        #     chain_type_kwargs={"prompt": prompt}
        # )
        # question = "What is the malware's behavior, and how does it interact with the compromised system?"
        # doc=retriever.get_relevant_documents(question)
        # print(doc)
        # result = rag_chain({"query": question})
        # # # rag_chain.invoke(result)
        # print(result["result"])
        # print(retriever)
        prompt = hub.pull("vivekpandit/llama-batch")

        # prompt = hub.pull("vivekpandit/flan-ul2")
        # #
        rag_chain = (
            {"context": retriever | format_docs, "question": RunnablePassthrough()}
            | prompt
            | retrieval_llm
            | StrOutputParser()
        )
        # #
        questions_types = glob.glob("../questions/*.questions")
        # print(questions_types)
        for question_type in questions_types:
            with open(question_type, "r") as f:
                questions = f.read()

            questions = questions.format(threat=self.threat)
            questions = questions.split("\n")
            print("questions---",questions)
            answers=[]
            for question in questions:
                # questions = questions.split("\n")
                answer = rag_chain.invoke(question)
                answers.append(answer)
                print(f"------Answers for {answer}-----")
            #
            details = ["Question: {}\nAnswer: {} \n ---------".format(q, a) for q, a in zip(questions, answers)]

            print(details)
            details="\n".join(details)
            section=question_type.split('/')[2].split('.')[0]
            with open("../sections/"+self.threat+'-'+section+".txt", "w") as f:
                f.write(details)
        # #     prompt_file=section+".prompt"
        # #     with open("../prompts/"+prompt_file, "r") as f:
        # #         prompt = f.read()
        # #
        # #     prompt = prompt.format(text=answer)
        # #     print("prompt----",prompt)
        # #     cleaned=llama_model.generate_text(prompt)
        # # #     answer = "\n".join(answer)
        # #     with open("../sections/"+self.threat+'-'+section+".txt", "w") as f:
        # #         f.write(cleaned)
        # end = time.time()
        # # print("collection---",vectorstore.get_collection())
        vectorstore.delete_collection()
        # print(f"Inferencing completed {end - start} seconds")
        files = glob.glob('../sections/*')
        print("Uploading files...")
        start = time.time()
        for f in files:
            print("file",f)
            self.cos.upload_file_cos(f, f.split('/')[2])
        end = time.time()
        print(f"Upload completed {end - start} seconds")
        return "Report created successfully"

# report = CreateReport("UNC3944")
# report.create_report()

