from fastapi import FastAPI, File, UploadFile
from create_report import CreateReport
from cos_connect import CosOperations
import shutil
import uvicorn
import glob
import time
import datetime
import os
import zipfile
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()
origins = [
    "http://localhost.tiangolo.com",
    "https://localhost.tiangolo.com",
    "http://localhost",
    "http://localhost:8080",
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
@app.post("/download")
async def download(threat:str):
    print("I am here 1")

    start_time = time.time()
    date = datetime.datetime.fromtimestamp(start_time).strftime('%Y-%m-%d')
    print("date:-", date)
    # all_files = glob.glob('../crawled/*')
    try:
        shutil.rmtree("../crawled")
    except OSError as e:
        print("Error: %s - %s." % (e.filename, e.strerror))
    if not os.path.exists("../crawled/"):
        os.makedirs("../crawled/")

    # # filenames = glob.glob('../crawled/*.txt')
    # with zipfile.ZipFile(zip_file, 'r') as zip_ref:
    #     zip_ref.extractall(extract_folder)
    print("Old files removed!")

    print("Starting downloading from COS...")
    cos = CosOperations()
    cos.download_all_files()
    print("Downloaded from COS!!!")
    end_time = time.time()
    print(f"Files downloaded in {end_time - start_time} seconds")
    txt_files = glob.glob("../crawled/*txt")
    print(txt_files)
    for f in txt_files:
        os.remove(f)
    all_files = glob.glob("../crawled/txt_files.zip")
    print(all_files)
    with zipfile.ZipFile(all_files[0], 'r') as zip_ref:
        zip_ref.extractall("../crawled")
    zip_files = glob.glob("../crawled/*zip")
    print(zip_files)
    for f in zip_files:
        os.remove(f)

    # txt_files = glob.glob("../crawled/*txt")
    # print(txt_files)
    # for f in txt_files:
    #     os.remove(f)
        # shutil.rmtree("../chroma")
        # os.makedirs("../chroma/")
    return {"message": "Files downloaded"}

@app.post("/vectorise")
async def vectorise(threat:str):
    report = CreateReport(threat)
    report.create_vector_db()
    return {"message": "Vector DB created"}
@app.post("/create_report")
async def vectorise(threat:str):
    try:
        shutil.rmtree("../sections")
    except OSError as e:
        print("Error: %s - %s." % (e.filename, e.strerror))
    if not os.path.exists("../sections/"):
        os.makedirs("../sections/")
    report = CreateReport(threat)
    report.create_report()

    return {"message": "Report Created"}

@app.post("/upload_questions")
async def upload_files(files: list[UploadFile] = File(...)):
    UPLOAD_DIR="../questions"
    try:
        for file in files:
            file_location = f"{UPLOAD_DIR}/{file.filename}"
            with open(file_location, "wb") as file_object:
                shutil.copyfileobj(file.file, file_object)
        response = "Prompts Uploaded"
    except Exception as e:
        response = e

    return {"message": response}

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8080, reload=True,ws_ping_timeout=1200)
