import ibm_boto3
from ibm_botocore.client import Config
from ibm_botocore.client import Config, ClientError


class CosOperations(object):
    def __init__(self) -> None:
        self.bucket_name = 'cyber'
        # Create resource
        self.cos_resource = ibm_boto3.resource("s3",
                                      ibm_api_key_id="aQEjno_ADf6jbepQWvZaX6xUIDUbadlJozgaNp6d--Eu",
                                      ibm_service_instance_id="crn:v1:bluemix:public:cloud-object-storage:global:a/725f5ce360ac4e589e3d57b609bfebf9:ff7ecb2f-e514-4ebc-8268-9851f5636093::",
                                      ibm_auth_endpoint="https://iam.cloud.ibm.com/identity/token",
                                      config=Config(signature_version="oauth"),
                                      endpoint_url="https://s3.us-south.cloud-object-storage.appdomain.cloud"
                                      )
        self.cos_client = ibm_boto3.client("s3",
                                      ibm_api_key_id="aQEjno_ADf6jbepQWvZaX6xUIDUbadlJozgaNp6d--Eu",
                                      ibm_service_instance_id="crn:v1:bluemix:public:cloud-object-storage:global:a/725f5ce360ac4e589e3d57b609bfebf9:ff7ecb2f-e514-4ebc-8268-9851f5636093::",
                                      ibm_auth_endpoint="https://iam.cloud.ibm.com/identity/token",
                                      config=Config(signature_version="oauth"),
                                      endpoint_url="https://s3.us-south.cloud-object-storage.appdomain.cloud"
                                      )

    def get_bucket_contents(self):
        print("Retrieving bucket contents from: {0}".format(self.bucket_name))
        file_list = []
        try:
            files = self.cos_resource.Bucket(self.bucket_name).objects.all()
            for file in files:
                file_list.append(file.key)
        except ClientError as be:
            print("CLIENT ERROR: {0}\n".format(be))
        except Exception as e:
            print("Unable to retrieve bucket contents: {0}".format(e))

        return file_list

    def download_file_cos(self, downloaded_file_name, path):
        try:
            # print("---Path----",path)
            res = self.cos_client.download_file(Bucket=self.bucket_name, Key=downloaded_file_name, Filename=path)
        except Exception as e:
            print(Exception, e)
        else:
            # print('File Downloaded')
            pass
        # self.__delete_file(key)
        return downloaded_file_name

    def upload_file_cos(self, local_file_name, key):
        try:
            res = self.cos_client.upload_file(Filename=local_file_name, Bucket=self.bucket_name, Key=key)
        except Exception as e:
            print(Exception, e)
        else:
            print(' File Uploaded')

    def download_all_files(self):
        local_path= "../crawled/"
        file_list = self.get_bucket_contents()
        for file in file_list:
            try:
                _file=file.split("/")[1]
            except:
                _file=file
            # print("----file----",local_path+_file)
            self.download_file_cos(file,local_path+_file)

# filename="h"
# stream = CosOperations()
# # stream.download_all_files("../text_files/")
#
# stream.upload_file_cos("../text_files/", filename)
