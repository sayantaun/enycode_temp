import React, { useState, useEffect } from "react";
import { Button, TextInput, Checkbox, CheckboxGroup, Accordion, AccordionItem, Heading, Section, TextArea, Link, ProgressBar } from "@carbon/react"
import { Add, TrashCan, DocumentDownload } from '@carbon/react/icons';

function CrawlPanel({ dataObj, threatnum, listsources }) {

    const [textBoxes, setTextBoxes] = useState([{ id: 0, value: '' }]);
    const [customUrlset, setcustomUrlset] = useState([]);
    const [crawlURLs, setcrawlURLs] = useState([]);

    var [sectionContent_bg, setsectionContent_bg] = useState();
    var [sectionContent_td, setsectionContent_td] = useState();
    var [sectionContent_ef, setsectionContent_ef] = useState();
    var [sectionContent_ttp, setsectionContent_ttp] = useState();
    var [sectionContent_rec, setsectionContent_rec] = useState();
    var [sectionContent_con, setsectionContent_con] = useState();

    var [progressbar, setprogressbar] = useState(false);
    var [progressstatus, setprogressstatus] = useState('active');
    var [progressstatusinfo, setprogressstatusinfo] = useState('');

    const addTextBox = () => {
        const newTextBoxes = [...textBoxes, { id: Date.now(), value: '' }];
        setTextBoxes(newTextBoxes);
    };

    const removeTextBox = (id) => {
        const updatedTextBoxes = textBoxes.filter((textBox) => textBox.id !== id);
        setTextBoxes(updatedTextBoxes);
    };

    const handleTextBoxChange = (id, value) => {
        const updatedTextBoxes = textBoxes.map((textBox) =>
            textBox.id === id ? { ...textBox, value } : textBox
        );
        setTextBoxes(updatedTextBoxes);
    };

    const [selectedsources1, setselectedsources1] = useState([]);
    const [selectAllChecked1, setSelectAllChecked1] = useState({});
    const [selectedNames, setselectedNames] = useState({});

    const handleCheckboxChange1 = (id, hyperlink, source) => {
        const updatedselectedsources = { ...selectedsources1 };
        const updatedselectedNames = { ...selectedNames };

        if (!updatedselectedsources[source]) {
            updatedselectedsources[source] = [];
            updatedselectedNames[source] = [];
        }

        const index = updatedselectedsources[source].indexOf(id);

        if (index === -1) {
            updatedselectedsources[source].push(id);
            updatedselectedNames[source].push(hyperlink);
        } else {
            updatedselectedsources[source].splice(index, 1);
            updatedselectedNames[source].splice(index, 1);
        }

        setselectedsources1(updatedselectedsources);
        setselectedNames(updatedselectedNames);

        const allSelected = dataObj
            .filter(item => item.source === source)
            .every(item => updatedselectedsources[source].includes(item.id));

        setSelectAllChecked1({
            ...selectAllChecked1,
            [source]: allSelected,
        });
    };

    const handleSelectAllChange1 = (source) => {
        const alllinks = dataObj
            .filter(item => item.source === source)
            .map((item) => item.id) || [];

        const allNames = dataObj
            .filter(item => item.source === source)
            .map((item) => item.hyperlink);

        setselectedsources1({
            ...selectedsources1,
            [source]: alllinks,
        });
        setselectedNames({
            ...selectedNames,
            [source]: allNames,
        });
        setSelectAllChecked1({
            ...selectAllChecked1,
            [source]: true,
        });
    };

    const handleDeselectAllChange1 = (source) => {
        setselectedsources1({
            ...selectedsources1,
            [source]: [],
        });
        setselectedNames({
            ...selectedNames,
            [source]: [],
        });
        setSelectAllChecked1({
            ...selectAllChecked1,
            [source]: false,
        });
    };

    function format_crawled_url(crawled_url){
        return crawled_url.replace("https:","http:").replace("http://www.","").replace(".com","");
    }

    function CrawledList(props) {
        const cdata = props.crawldata
        const csource = props.crawlsource
        const cl = cdata.map((item,index) => {
            
            if ((item.source === csource)) {
                return (
                    <CheckboxGroup>
                        <Checkbox id={item.id} checked={selectedsources1[item.source]?.includes(item.id)} onChange={() => handleCheckboxChange1(item.id, item.hyperlink, item.source)} labelText={<Link href={item.hyperlink}>{format_crawled_url(item.hyperlink)}</Link>} />           
                    </CheckboxGroup>
                )
            }
            return null;
        })

        return cl;
    }

    var finalpayloadcpsv = { 'selected_links': JSON.stringify(crawlURLs), 'search_query': threatnum };

    async function loadReportContents() {

        setprogressbar(true);
        setprogressstatus('active');
        var threatNumber = threatnum;

        try{
            const reqOpts = {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(finalpayloadcpsv),
            };
            const reqOpts1 = {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
            };
            let resp = await fetch(process.env.REACT_APP_S2, reqOpts);
            setprogressstatusinfo('Crawling sites...');
            if (resp.status === 200) {
            let response1 = await fetch(`${process.env.REACT_APP_I1}?threat=${threatNumber}`, reqOpts1);
            setprogressstatusinfo('Loading crawled data...');
            if (response1.status === 200) {
                let response2 = await fetch(`${process.env.REACT_APP_I2}?threat=${threatNumber}`, reqOpts1);
                setprogressstatusinfo('Vectorising data...');
                if (response2.status === 200) {
                    let response3 = await fetch(`${process.env.REACT_APP_I3}?threat=${threatNumber}`, reqOpts1);
                    setprogressstatusinfo('Generating report contents...');

                    if (response3.status === 200) {
                        var sections =
                        {
                            "background": setsectionContent_bg,
                            "technicaldetails": setsectionContent_td,
                            "executionflow": setsectionContent_ef,
                            "tacticstechniquesprocedures": setsectionContent_ttp,
                            "recommendation": setsectionContent_rec,
                            "conclusion": setsectionContent_con
                        }

                        for (let eachsection in sections) {
                            let response = await fetch(`/getcosfiles?threatnumber=${threatNumber}&section=${eachsection}`);
                            let result = await response.status;
                            if (result === 200) {
                                console.log('success');
                            }
                            else {
                                console.log('issue with file in cos');
                            }
                        }
                    }
                    else {
                        console.log('Issue with report creation service');
                        setprogressstatus('error');
                        setprogressstatusinfo('Issue with report creation service');
                    }
                }
                else {
                    console.log('Issue with vectorise service');
                    setprogressstatus('error');
                    setprogressstatusinfo('Issue with vectorise service');
                }
            }
            else {
                console.log('Issue with download service');
                setprogressstatus('error');
                setprogressstatusinfo('Issue with loading service');
            }
        }
              else {
                setprogressstatus('error');
                setprogressstatusinfo('Issue with crawl service');
                console.log('Issue with crawl service');
            }

            return "success";
        }
        catch(err){
            setprogressstatus('error');
            setprogressstatusinfo('Issue with backend');
            console.log('Issue with backend');
            return "failure";
        }
 
    }

    const fetchFileContent = async () => {

        try {
            const lrcres = await loadReportContents();
            
            if(lrcres === "success"){
                setprogressstatusinfo('Fetching report contents...');
                try {
                    let sectionname1 = "background"
                    const responsebg = await fetch(`/getFileContent?section=${sectionname1}&threat=${threatnum}`);
                    const databg = await responsebg.json();
                    setsectionContent_bg(databg.content);
                } catch (error1) {
                    console.error('Error fetching file content:', error1);
                }
                try {
                    let sectionname2 = "technicaldetails"
                    const responsetd = await fetch(`/getFileContent?section=${sectionname2}&threat=${threatnum}`);
                    const datatd = await responsetd.json();
                    setsectionContent_td(datatd.content);
                } catch (error2) {
                    console.error('Error fetching file content:', error2);
                }
                try {
                    let sectionname3 = "executionflow"
                    const responseef = await fetch(`/getFileContent?section=${sectionname3}&threat=${threatnum}`);
                    const dataef = await responseef.json();
                    setsectionContent_ef(dataef.content);
                } catch (error) {
                    console.error('Error fetching file content:', error);
                }
                try {
                    let sectionname4 = "tacticstechniquesprocedures"
                    const responsettp = await fetch(`/getFileContent?section=${sectionname4}&threat=${threatnum}`);
                    const datattp = await responsettp.json();
                    setsectionContent_ttp(datattp.content);
                } catch (error) {
                    console.error('Error fetching file content:', error);
                }
                try {
                    let sectionname5 = "recommendation"
                    const responserec = await fetch(`/getFileContent?section=${sectionname5}&threat=${threatnum}`);
                    const datarec = await responserec.json();
                    setsectionContent_rec(datarec.content);
                } catch (error) {
                    console.error('Error fetching file content:', error);
                }
                try {
                    let sectionname6 = "conclusion"
                    const responsecon = await fetch(`/getFileContent?section=${sectionname6}&threat=${threatnum}`);
                    const datacon = await responsecon.json();
                    setsectionContent_con(datacon.content);
                } catch (error6) {
                    console.error('Error fetching file content:', error6);
                }
                setprogressstatus('finished');
                setprogressstatusinfo('Report Generation Completed');
            }
            else{
                console.log('Backend issue');
                setprogressstatus('error');
                setprogressstatusinfo('Issue with Backend service');
            }
        }
       catch(err){
            console.log('content error');
        }
    };

    const compileReport = async (e) => {

        var finalcontent = `${threatnum}@@Advisory Report for Threat ${threatnum}.\n\n\nBackground:\n${sectionContent_bg}\n\nTechnical Details:\n${sectionContent_td}\n\nExecution Flow:\n${sectionContent_ef}\n\nTactics Techniques Procedures:\n${sectionContent_ttp}\n\nRecommendations:\n${sectionContent_rec}\n\nConclusion:\n${sectionContent_con}\n\n`;

        try {
            const response = await fetch('/createreport', {
                method: 'POST',
                headers: {
                    'Content-Type': 'text/plain',
                },
                body: finalcontent,
            });

            if (!response.ok) {
                throw new Error(`Failed to save data to doc file: ${response.status} ${response.statusText}`);
            }

        } catch (error) {
            console.error('Error saving data to doc file:', error.message);
        }
    };

    const downloadReport = async (e) => {
        await compileReport();
        var rem = 'final-report.doc';
        var fname = threatnum + '-' + rem;
        e.preventDefault();
        window.open(`/download?filename=${fname}`,)

        setprogressbar(false);
    }

    useEffect(() => {

        let updatedurlList = textBoxes
            .filter((item) => item.value.trim() !== '')
            .map((item) => item.value);

        setcustomUrlset(updatedurlList);

    }, [textBoxes]);


    useEffect(() => {

        const allSelectedValues = Object.values(selectedNames).flat();
        let combinedUrlset = [...allSelectedValues, ...customUrlset];
        setcrawlURLs(combinedUrlset);

    }, [selectedNames, customUrlset]);


    function srceChk(source) {
        return dataObj.some(item => item.source === source);
    }

    function srceCount(source) {
        if (dataObj.length > 0){
            return `${source}  (${dataObj.filter(item => item.source === source.toLowerCase()).length})`;
        }
        return source;
    }

    return (
        <>
            <Section level={4}>
                <Heading>Review Crawled Sites for each section</Heading>
            </Section>

        <br/>
        <br/>
            <Accordion>
                {listsources.map((srce) => (
                    <AccordionItem title={srceCount(srce)}>

                        {srceChk(srce.toLowerCase()) && dataObj.length > 0 ? (
                        <>
                        <CheckboxGroup>
                            <Checkbox id={`selectAll-${srce.toLowerCase()}`} labelText="Select all sites" checked={selectAllChecked1[srce.toLowerCase()]} onChange={selectAllChecked1[srce.toLowerCase()] ? () => handleDeselectAllChange1(srce.toLowerCase()) : () => handleSelectAllChange1(srce.toLowerCase())} />
                        </CheckboxGroup> <CrawledList crawldata={dataObj} crawlsource={srce.toLowerCase()}/>
                        </>) : (<p>No Results</p>)}         

                    </AccordionItem>
                ))}
            </Accordion> 

            <br />
            <br />
            <br />

            <Section level={6}>
                <Heading>Add sites to crawl</Heading>
            </Section>
            <br />
            
            <div style={{
                marginBottom: "10px", display: "block", alignItems: "right"
            }}>
            {textBoxes.map((textBox) => (
               <>
                <div>
                   <TextInput type="text" id={textBox.id} labelText={'URL to crawl'} placeholder={'hyperlink to crawl'} size='md' value={textBox.value} onChange={(e) => {handleTextBoxChange(textBox.id, e.target.value);}} />
                </div>
                    
                    <div style={{ padding: "8px 8px", marginLeft: "8px", textAlign: "right" }}>
                        <Button hasIconOnly renderIcon={TrashCan} kind="secondary" type="button" onClick={() => removeTextBox(textBox.id)} iconDescription="Remove" />
                    </div>
                </>
                
            ))}
            <div style={{ padding: "8px 8px", textAlign: "right" }}>               
                    <Button hasIconOnly renderIcon={Add} type="button" onClick={addTextBox} iconDescription="Add" />
                </div>
            </div>
 
            <br />

            <div className="ButtonArea">
                <Button type="submit" onClick={() => { fetchFileContent(); }}> Generate Report </Button> 
            </div>
            <br />
            <br />
            {progressbar && 
                <ProgressBar label="Report Generation Progress" helperText={progressstatusinfo} size="big" status={progressstatus} />
            }
            <br />
            <br />
            <br />
            <br />

            {progressstatus === "finished" ? (<>
                <TextArea
                    id="background"
                    labelText="Threat Advisory Section - Background"
                    placeholder="Threat Advisory Section - Background"
                    rows={20}
                    size="lg"
                    value={sectionContent_bg}
                    onChange={(e) => setsectionContent_bg(e.target.value)}
                />
                <br />
                <TextArea
                    id="technical-details"
                    labelText="Threat Advisory Section - Technical Details"
                    placeholder="Threat Advisory Section - Technical Details"
                    rows={20}
                    size="lg"
                    value={sectionContent_td}
                    onChange={(e) => setsectionContent_td(e.target.value)}
                />
                <br />
                <TextArea
                    id="execution-flows"
                    labelText="Threat Advisory Section - Execution Flows"
                    placeholder="Threat Advisory Section - Execution Flows"
                    rows={20}
                    size="lg"
                    value={sectionContent_ef}
                    onChange={(e) => setsectionContent_ef(e.target.value)}
                />
                <br />
                <TextArea
                    id="ttp"
                    labelText="Threat Advisory Section - TTPs"
                    placeholder="Threat Advisory Section - TTPs"
                    rows={20}
                    size="lg"
                    value={sectionContent_ttp}
                    onChange={(e) => setsectionContent_ttp(e.target.value)}
                />
                <br />
                <TextArea
                    id="recommendations"
                    labelText="Threat Advisory Section - Recommendations"
                    placeholder="Threat Advisory Section - Recommendations"
                    rows={20}
                    size="lg"
                    value={sectionContent_rec}
                    onChange={(e) => setsectionContent_rec(e.target.value)}
                />
                <br />
                <TextArea
                    id="conclusion"
                    labelText="Threat Advisory Section - Conclusion"
                    placeholder="Threat Advisory Section - Conclusion"
                    rows={20}
                    size="lg"
                    value={sectionContent_con}
                    onChange={(e) => setsectionContent_con(e.target.value)}
                />
                <br />
                
                <div className="ButtonArea">
                    <Button type="submit" onClick={(e) => { compileReport(); downloadReport(e); }} style={{ height: "52px", paddingRight: "40px" }}> Get Report  <DocumentDownload style={{ marginLeft: "8px", paddingBottom: "14px", height: "30px" }} /></Button>
                </div>
            </>) : (<></>)}

                   </>
    )
}

export default CrawlPanel;