import React from "react";
import { Header, HeaderName,Theme } from "@carbon/react"
import Threatmain from "./threatMain.js";
import './App.css';

function App() {
  return (
    <>
      <Theme theme='g90'>
      <Header aria-label="">
                <HeaderName prefix="IBM watsonx">
                    <div style={{ whiteSpace: "nowrap", padding: "16px" }}>
                        CyberSecurity AI
                    </div>
                </HeaderName>
            </Header>
        </Theme>

      <div>
        <div className="pagebanner" style={{ backgroundImage: `url(${process.env.PUBLIC_URL + "/banner.jpg"})` }} >
          <div className="pagebanner-title"><b>Emerging Threat Advisory AI</b></div>
        </div>

        <div className="App" >
          <Threatmain />
        </div>
            </div>
    </>
  );
}

export default App;
