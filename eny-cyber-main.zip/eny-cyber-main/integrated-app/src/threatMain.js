import React, { useState } from "react";
import { Button, TextInput, Checkbox, CheckboxGroup, Loading } from "@carbon/react"
import CrawlPanel from "./crawlPanel";

function Threatmain() {

    const sourceslist = [

        {
            id: 'http://www.duckduckgo.com',
            value: 'Duckduckgo',
            display: 'Duckduckgo (All Languages)',
        },
        {
            id: 'https://www.google.com',
            value: 'Google',
            display: 'Google (English)',
        },
        {
            id: 'http://www.nate.com',
            value: 'Nate',
            display: 'Nate (Korean)',
        },
        {
            id: 'http://www.naver.com',
            value: 'Naver',
            display: 'Naver (Korean)',
        },
        {
            id: 'http://yandex.com',
            value: 'Yandex',
            display: 'Yandex (Russian)',
        }

    ];

    const [threatnumber, setthreatnumber] = useState('');
    const [dataCrawl, setdataCrawl] = useState([]);
    const [isLoading, setLoading] = useState(false);
    const [selectedsources, setselectedsources] = useState([]);
    const [selectAllChecked, setSelectAllChecked] = useState(false);
    const [selectedNames, setselectedNames] = useState([]);

    const handleCheckboxChange = (id, value) => {
        const updatedselectedsources = [...selectedsources];
        const updatedselectedNames = [...selectedNames];

        const index = updatedselectedsources.indexOf(id);

        if (index === -1) {
            updatedselectedsources.push(id);
            updatedselectedNames.push(value);
        } else {
            updatedselectedsources.splice(index, 1);
            updatedselectedNames.splice(index, 1);
        }

        setselectedsources(updatedselectedsources);
        setselectedNames(updatedselectedNames);
        setSelectAllChecked(updatedselectedsources.length === sourceslist.length);
    };

    const handleSelectAllChange = () => {
        const allIds = sourceslist.map((item) => item.id);
        const allNames = sourceslist.map((item) => item.value);

        setselectedsources(allIds);
        setselectedNames(allNames);
        setSelectAllChecked(true);
    };

    const handleDeselectAllChange = () => {
        setselectedsources([]);
        setselectedNames([]);
        setSelectAllChecked(false);
    };


    async function getCrawlcontent(){

        setLoading(true);
        var finalpayloadtm = { 'search_engine': JSON.stringify(selectedNames), 'search_query': threatnumber };
        try {
            const reqOpts = {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(finalpayloadtm),
            };
            let response = await fetch(process.env.REACT_APP_S1, reqOpts);
            let res = await response.json();
            if (res === null){
                setdataCrawl([])
            }
            setdataCrawl([...res]);
            setLoading(false);
        }
        catch(err){
            console.log('Issue accessing crawl service');
            setLoading(false);
        }
    }

    return (
        <>
            <TextInput type="text" id={'threatnumber'} labelText={'Threat Name*'} placeholder={'Threat ID/Name'} size='lg' value={threatnumber} onChange={(event) => { setthreatnumber(event.target.value); }} />
            <br />
            <br />
            <CheckboxGroup legendText="Select source(s) to crawl">
                <Checkbox checked={selectAllChecked} onChange={selectAllChecked ? handleDeselectAllChange : handleSelectAllChange} labelText="Select all sources" id="Select all" />
                {sourceslist.map((item, i) => {
                    return (
                        <>
                            <Checkbox id={item.id} checked={selectedsources.includes(item.id)} onChange={() => handleCheckboxChange(item.id, item.value)} labelText={item.display} />
                        </>
                    )
                })}
            </CheckboxGroup>
            
            <div className="ButtonArea">
                <Button type="submit" onClick={() => { getCrawlcontent(); }} > Begin Crawl </Button>
            </div>
            <br />
            <br />
            <br />
            <Loading active={isLoading} description="Active loading" withOverlay={true} />

            <CrawlPanel dataObj={dataCrawl} threatnum={threatnumber} listsources={selectedNames}/>
        </>

    )
}

export default Threatmain;