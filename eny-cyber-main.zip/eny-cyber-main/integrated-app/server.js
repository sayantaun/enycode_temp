const bodyParser = require('body-parser');
const path = require('path');
const express = require('express')
const fs = require('fs');
const stream = require('stream');
const cors = require('cors');
const fsp = require('fs').promises;
const IBM = require('ibm-cos-sdk');
const dotenv = require('dotenv');
dotenv.config({ path: './.env' })

const app = express();
app.use(cors());
app.use(express.static("./build"));
app.use(express.static("./advisory-details"));
app.use(bodyParser.text()); 

var config = {
    endpoint: `${process.env.ENDPOINT}`,
    apiKeyId: `${process.env.APIKEY}`,
    serviceInstanceId: `${process.env.SERVICE_INSTANCE}`,
    signatureVersion: 'iam',
};

var cos = new IBM.S3(config);

async function getItem(bucketName, itemName, section) {
    console.log(`Retrieving item from bucket: ${bucketName}, key: ${itemName}`);
    try {
        const data = await cos.getObject({
            Bucket: bucketName,
            Key: itemName,
        }).promise();

        if (data != null) {
            const responseBody = Buffer.from(data.Body);

            // Save the response to a file
            const folderPath = 'advisory-details';
            if (!fs.existsSync(folderPath)) {
                fs.mkdirSync(folderPath);
            }

            const filePath = `./${folderPath}/${itemName}`;
            const fileStream = fs.createWriteStream(filePath);

            const readableStream = new stream.Readable();
            readableStream.push(responseBody);
            readableStream.push(null);

            readableStream.pipe(fileStream);

            await new Promise((resolve, reject) => {
                fileStream.on('finish', resolve);
                fileStream.on('error', reject);
            });

            console.log(`Response saved to: ${filePath}`);
        }
    } catch (e) {
        console.error(`ERROR: ${e.code} - ${e.message}\n`);
    }
}

app.get("/getcosfiles", function (req, resp) {
    let cosfilename = req.query.threatnumber + '-' + req.query.section + '.txt';
    let sectionname = req.query.section;

    getItem(`${process.env.BUCKET}`, cosfilename, sectionname)
        .then((res) => {
            resp.status(200).json({ "msg": 'Item retrieval and response saving complete.' })
            console.log('Item retrieval and response saving complete.');
        })
        .catch((error) => {
            resp.status(404).json({ "msg": "Unable to fetch files from COS" })
            console.error('Error:', error);
        });
});

app.get("/download?:filename", async (req, res) => {
    let filepath = `/advisory-details/${req.query.filename}`
    try {
        res.download(`${__dirname}${filepath}`)
    }
    catch {
        res.download(`${__dirname}${filepath}`)
    }
})


app.post('/createreport', async (req, res) => {
    let folderPath = './advisory-details';
    try {
        const [tnum, data] = req.body.split('@@');
        const filePath = path.join(__dirname, `${folderPath}`, `${tnum}-final-report.doc`);
        fs.writeFile(filePath, data, { encoding: 'utf-8' }, (err) => {
            if (err) {
                console.error('Error saving data to doc file:', err);
                res.status(500).send('Internal Server Error: ' + err.message);
            } else {
                res.status(200).send('Data successfully saved to doc file!');
            }
        });
    } catch (error) {
        console.error('Error saving data to doc file:', error);
        res.status(500).send('Internal Server Error: ' + error.message);
    }
});

app.get('/getFileContent', async (req, res) => {
    let secname = req.query.section;
    let threatname = req.query.threat;
    let folderPath = './advisory-details';
    try {
        const filePath = path.join(__dirname, `${folderPath}`, `${threatname}-${secname}.txt`);
        const fileContent = await fsp.readFile(filePath, { encoding: 'utf-8' });
        res.json({ content: fileContent });
    } catch (error) {
        console.error('Error reading file:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

app.listen(3000, () => {
    console.log('server listening on port 3000')
})