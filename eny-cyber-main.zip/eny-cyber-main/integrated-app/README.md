# EY Cyber App for Emerging Threat Advisory

To start the integrated application, run the following commands (inside the `integrated-app` folder):
1. `npm install`
2. `npm run build`
3. `npm run server`

- Ensure to obtain the required credentials for the COS bucket used in the .env file <br>
- The integrated app runs on port 3000 and has been deployed to code engine
